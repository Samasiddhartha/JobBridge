<?php
error_reporting(0);
header('Content-Type: application/json');
include "db.php";

// Get POST data - support both mobile and email identifiers
$mobile = isset($_POST['mobile']) ? trim($_POST['mobile']) : '';
$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';
$user_type = isset($_POST['user_type']) ? trim($_POST['user_type']) : '';

// Use the identifier that was provided
$identifier = !empty($email) ? $email : $mobile;

// Validate input
if (empty($identifier) || empty($password)) {
    echo json_encode([
        "success" => false,
        "message" => "Identifier and new password are required"
    ]);
    exit;
}

// Validate password length
if (strlen($password) < 6) {
    echo json_encode([
        "success" => false,
        "message" => "Password must be at least 6 characters"
    ]);
    exit;
}

// Check if there's a valid verified OTP for this identifier (check both worker and employer purposes)
$otpStmt = $conn->prepare("SELECT id, purpose FROM otp_codes WHERE mobile = ? AND is_used = 0 AND (purpose LIKE 'forgot_password%') AND expires_at > NOW() ORDER BY created_at DESC LIMIT 1");
$otpStmt->bind_param("s", $identifier);
$otpStmt->execute();
$otpResult = $otpStmt->get_result();

if ($otpResult->num_rows == 0) {
    echo json_encode([
        "success" => false,
        "message" => "No valid OTP found. Please request a new OTP"
    ]);
    $otpStmt->close();
    exit;
}

$otpRow = $otpResult->fetch_assoc();
$otpStmt->close();

// Determine user type from OTP purpose
$detected_user_type = 'worker';
if (strpos($otpRow['purpose'], 'employer') !== false) {
    $detected_user_type = 'employer';
}

// Override with explicit user_type if provided
if (!empty($user_type)) {
    $detected_user_type = $user_type;
}

// Store password as plain text (for testing/academic purposes)
$plainPassword = $password;

// Update password in appropriate table
$success = false;
if ($detected_user_type === 'employer') {
    // Try updating by email first, then by mobile
    $updateStmt = $conn->prepare("UPDATE employers SET password = ? WHERE email = ? OR mobile = ?");
    $updateStmt->bind_param("sss", $plainPassword, $identifier, $identifier);
    if ($updateStmt->execute() && $updateStmt->affected_rows > 0) {
        $success = true;
    }
    $updateStmt->close();
} else {
    // Update workers table by mobile
    $updateStmt = $conn->prepare("UPDATE workers SET password = ? WHERE mobile = ?");
    $updateStmt->bind_param("ss", $plainPassword, $identifier);
    if ($updateStmt->execute() && $updateStmt->affected_rows > 0) {
        $success = true;
    }
    $updateStmt->close();
}

if ($success) {
    // Mark all OTPs for this identifier as used
    $markUsedStmt = $conn->prepare("UPDATE otp_codes SET is_used = 1 WHERE mobile = ?");
    $markUsedStmt->bind_param("s", $identifier);
    $markUsedStmt->execute();
    $markUsedStmt->close();
    
    echo json_encode([
        "success" => true,
        "message" => "Password reset successfully"
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "User not found or password not changed"
    ]);
}

$conn->close();
?>
