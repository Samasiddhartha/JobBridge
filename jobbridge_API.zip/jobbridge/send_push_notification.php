<?php
/**
 * Firebase Cloud Messaging (FCM) Push Notification Helper
 * Uses FCM HTTP v1 API with Service Account authentication
 */

// Path to Firebase Admin SDK service account JSON file
define('FIREBASE_CREDENTIALS_PATH', __DIR__ . '/job-bridge-aeb58-firebase-adminsdk-fbsvc-fbecd70f19.json');
define('FIREBASE_PROJECT_ID', 'job-bridge-aeb58');

/**
 * Get OAuth2 access token from service account credentials
 * @return string|null Access token or null on failure
 */
function getAccessToken() {
    $credentials = json_decode(file_get_contents(FIREBASE_CREDENTIALS_PATH), true);
    
    if (!$credentials) {
        return null;
    }
    
    // Create JWT header
    $header = base64_encode(json_encode(['alg' => 'RS256', 'typ' => 'JWT']));
    
    // Create JWT claim set
    $now = time();
    $claim = base64_encode(json_encode([
        'iss' => $credentials['client_email'],
        'scope' => 'https://www.googleapis.com/auth/firebase.messaging',
        'aud' => 'https://oauth2.googleapis.com/token',
        'iat' => $now,
        'exp' => $now + 3600
    ]));
    
    // Sign with private key
    $signature = '';
    $data = $header . '.' . $claim;
    openssl_sign($data, $signature, $credentials['private_key'], 'SHA256');
    $signature = base64_encode($signature);
    
    // Create JWT
    $jwt = $data . '.' . str_replace(['+', '/', '='], ['-', '_', ''], $signature);
    
    // Exchange JWT for access token
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://oauth2.googleapis.com/token');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
        'assertion' => $jwt
    ]));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    $response = json_decode(curl_exec($ch), true);
    curl_close($ch);
    
    return isset($response['access_token']) ? $response['access_token'] : null;
}

/**
 * Send a push notification to a specific device
 * 
 * @param string $fcm_token The device's FCM token
 * @param string $title Notification title
 * @param string $message Notification message body
 * @param string $type Notification type for app handling
 * @param array $extra_data Optional additional data
 * @return bool Success status
 */
function sendPushNotification($fcm_token, $title, $message, $type = 'general', $extra_data = []) {
    if (empty($fcm_token)) {
        return false;
    }
    
    $accessToken = getAccessToken();
    if (!$accessToken) {
        error_log("FCM: Failed to get access token");
        return false;
    }
    
    $url = 'https://fcm.googleapis.com/v1/projects/' . FIREBASE_PROJECT_ID . '/messages:send';
    
    $payload = [
        'message' => [
            'token' => $fcm_token,
            'notification' => [
                'title' => $title,
                'body' => $message
            ],
            'data' => array_merge([
                'title' => $title,
                'message' => $message,
                'type' => $type
            ], $extra_data),
            'android' => [
                'priority' => 'high',
                'notification' => [
                    'sound' => 'default',
                    'click_action' => 'OPEN_ACTIVITY'
                ]
            ]
        ]
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $accessToken,
        'Content-Type: application/json'
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($http_code != 200) {
        error_log("FCM Error: " . $response);
    }
    
    return $http_code == 200;
}

/**
 * Send push notification to a user by their ID and type
 * 
 * @param mysqli $conn Database connection
 * @param int $user_id User ID
 * @param string $user_type 'worker' or 'employer'
 * @param string $title Notification title
 * @param string $message Notification message
 * @param string $type Notification type
 * @return bool Success status
 */
function sendPushToUser($conn, $user_id, $user_type, $title, $message, $type = 'general') {
    // Get user's FCM token
    if ($user_type === 'worker') {
        $sql = "SELECT fcm_token FROM workers WHERE id = ?";
    } else {
        $sql = "SELECT fcm_token FROM employers WHERE id = ?";
    }
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        $fcm_token = $row['fcm_token'];
        if (!empty($fcm_token)) {
            return sendPushNotification($fcm_token, $title, $message, $type);
        }
    }
    
    return false;
}
?>
