# JobBridge PHP API

## Deployment Instructions

### 1. Copy Files to XAMPP
Copy all PHP files from this folder to:
```
C:\xampp\htdocs\jobbridge\
```

### 2. Create Uploads Folder
Create the uploads directory with write permissions:
```
C:\xampp\htdocs\jobbridge\uploads\
```

### 3. Import Database
Import the database schema:
- Open phpMyAdmin (http://localhost/phpmyadmin)
- Create database named `jobbridge`
- Import `../database/jobbridge_complete.sql`

### 4. Verify Database Connection
Check `db.php` settings:
```php
$host = "localhost";
$username = "root";
$password = "";       // Default XAMPP password (empty)
$database = "jobbridge";
$port = 3306;
```

## API Endpoints

### Authentication
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/signup.php` | Register worker/employer |
| POST | `/worker_login.php` | Worker login |
| POST | `/employer_login.php` | Employer login |
| POST | `/forgot_password.php` | Request password reset |
| POST | `/verify_otp.php` | Verify OTP code |
| POST | `/reset_password.php` | Set new password |

### Jobs
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/post_job.php` | Create new job posting |
| GET | `/get_all_jobs.php` | List all active jobs |
| GET | `/job_details.php?job_id=X` | Get job details |
| GET | `/search_jobs.php?q=keyword` | Search jobs |
| GET | `/filter_jobs.php` | Filter jobs by category |
| POST | `/update_job.php` | Update job posting |
| POST | `/close_job.php` | Close job posting |
| GET | `/get_categories.php` | List all categories |

### Applications
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/apply_job.php` | Apply for job |
| GET | `/get_my_applications.php?worker_id=X` | Worker's applications |
| GET | `/get_applicants.php?job_id=X` | Job applicants (employer) |
| POST | `/update_application_status.php` | Accept/reject applicant |
| POST | `/withdraw_application.php` | Withdraw application |

### Profiles
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/get_profile.php?worker_id=X` | Get worker profile |
| POST | `/update_profile.php` | Update worker profile |
| GET | `/get_employer_profile.php?employer_id=X` | Get employer profile |
| POST | `/update_employer_profile.php` | Update employer profile |
| GET | `/get_worker_details.php?worker_id=X` | Full worker details |
| POST | `/upload_document.php` | Upload photo/document |

### Saved Jobs
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/save_job.php` | Save/unsave job |
| GET | `/get_saved_jobs.php?worker_id=X` | Get saved jobs |

### Ratings
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/rate_worker.php` | Employer rates worker |
| POST | `/rate_employer.php` | Worker rates employer |
| GET | `/get_worker_ratings.php?worker_id=X` | Get worker ratings |

### Messaging
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/send_message.php` | Send chat message |
| GET | `/get_messages.php` | Get chat messages |
| GET | `/get_conversations.php` | List conversations |

### Misc
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/get_notifications.php?user_id=X&user_type=worker` | Get notifications |
| POST | `/mark_notification_read.php` | Mark notification read |
| GET | `/dashboard_counts.php?employer_id=X` | Employer dashboard stats |
| GET | `/get_employer_jobs.php?employer_id=X` | Employer's jobs |
| GET | `/get_work_history.php?worker_id=X` | Worker's history |

## Testing
Base URL: `http://10.0.2.2/jobbridge/` (Android Emulator)
Base URL: `http://localhost/jobbridge/` (Browser)

## File List (39 files)
```
apply_job.php
close_job.php
dashboard_counts.php
db.php
employer_login.php
filter_jobs.php
forgot_password.php
get_all_jobs.php
get_applicants.php
get_categories.php
get_conversations.php
get_employer_jobs.php
get_employer_profile.php
get_messages.php
get_my_applications.php
get_notifications.php
get_profile.php
get_saved_jobs.php
get_work_history.php
get_worker_details.php
get_worker_ratings.php
job_details.php
mark_notification_read.php
post_job.php
rate_employer.php
rate_worker.php
reset_password.php
save_job.php
search_jobs.php
send_message.php
signup.php
update_application_status.php
update_employer_profile.php
update_job.php
update_profile.php
upload_document.php
verify_otp.php
withdraw_application.php
worker_login.php
```
