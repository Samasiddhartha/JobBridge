<?php
error_reporting(0);
header('Content-Type: application/json');
include 'db.php';

// Get POST data
$data = json_decode(file_get_contents("php://input"), true);

$sender_id = isset($data['sender_id']) ? intval($data['sender_id']) : 0;
$sender_type = isset($data['sender_type']) ? $data['sender_type'] : '';
$receiver_id = isset($data['receiver_id']) ? intval($data['receiver_id']) : 0;
$receiver_type = isset($data['receiver_type']) ? $data['receiver_type'] : '';
$job_id = isset($data['job_id']) ? intval($data['job_id']) : null;
$message = isset($data['message']) ? trim($data['message']) : '';

// Validate required fields
if ($sender_id <= 0 || $receiver_id <= 0) {
    echo json_encode(["success" => false, "message" => "Sender and Receiver IDs are required"]);
    exit;
}

if (!in_array($sender_type, ['worker', 'employer']) || !in_array($receiver_type, ['worker', 'employer'])) {
    echo json_encode(["success" => false, "message" => "Invalid sender or receiver type"]);
    exit;
}

if (empty($message)) {
    echo json_encode(["success" => false, "message" => "Message cannot be empty"]);
    exit;
}

// Insert message
$sql = "INSERT INTO messages (sender_id, sender_type, receiver_id, receiver_type, job_id, message) 
        VALUES (?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("isisss", $sender_id, $sender_type, $receiver_id, $receiver_type, $job_id, $message);

if ($stmt->execute()) {
    $message_id = $conn->insert_id;
    
    // Get the sender's name
    $sender_name = "";
    if ($sender_type === 'worker') {
        $sql = "SELECT name FROM workers WHERE id = ?";
    } else {
        $sql = "SELECT company_name as name FROM employers WHERE id = ?";
    }
    $stmt2 = $conn->prepare($sql);
    $stmt2->bind_param("i", $sender_id);
    $stmt2->execute();
    $result = $stmt2->get_result();
    if ($row = $result->fetch_assoc()) {
        $sender_name = $row['name'];
    }
    
    // Send notification to receiver
    $notif_title = "New Message from " . $sender_name;
    $notif_message_text = substr($message, 0, 50) . (strlen($message) > 50 ? "..." : "");
    $sql = "INSERT INTO notifications (user_id, user_type, title, message, type, reference_id) VALUES (?, ?, ?, ?, 'message', ?)";
    $stmt3 = $conn->prepare($sql);
    $stmt3->bind_param("isssi", $receiver_id, $receiver_type, $notif_title, $notif_message_text, $message_id);
    $stmt3->execute();
    
    // Send push notification to receiver
    require_once 'send_push_notification.php';
    sendPushToUser($conn, $receiver_id, $receiver_type, $notif_title, $notif_message_text, 'message');
    
    echo json_encode([
        "success" => true,
        "message" => "Message sent successfully",
        "message_id" => $message_id,
        "created_at" => date("Y-m-d H:i:s")
    ]);
} else {
    echo json_encode(["success" => false, "message" => "Failed to send message"]);
}

$stmt->close();
$conn->close();
?>
