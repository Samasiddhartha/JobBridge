<?php
error_reporting(0);
header('Content-Type: application/json');
include "db.php";

$employer_id = isset($_POST['employer_id']) ? intval($_POST['employer_id']) : 0;
$company_name = isset($_POST['company_name']) ? trim($_POST['company_name']) : '';
$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$mobile = isset($_POST['mobile']) ? trim($_POST['mobile']) : '';
$industry = isset($_POST['industry']) ? trim($_POST['industry']) : '';
$website = isset($_POST['website']) ? trim($_POST['website']) : '';
$address = isset($_POST['address']) ? trim($_POST['address']) : '';
$city = isset($_POST['city']) ? trim($_POST['city']) : '';
$about = isset($_POST['about']) ? trim($_POST['about']) : '';
$gst_number = isset($_POST['gst_number']) ? trim($_POST['gst_number']) : '';
$company_size = isset($_POST['company_size']) ? trim($_POST['company_size']) : '';

if ($employer_id <= 0) {
    echo json_encode(["success" => false, "message" => "Invalid employer ID"]);
    exit;
}

if (empty($company_name)) {
    echo json_encode(["success" => false, "message" => "Company name is required"]);
    exit;
}

// Build dynamic update query
$updates = [];
$types = "";
$values = [];

$updates[] = "company_name = ?";
$types .= "s";
$values[] = $company_name;

if (!empty($email)) {
    $updates[] = "email = ?";
    $types .= "s";
    $values[] = $email;
}

if (!empty($mobile)) {
    $updates[] = "mobile = ?";
    $types .= "s";
    $values[] = $mobile;
}

if (!empty($industry)) {
    $updates[] = "industry = ?";
    $types .= "s";
    $values[] = $industry;
}

if (!empty($website)) {
    $updates[] = "website = ?";
    $types .= "s";
    $values[] = $website;
}

if (!empty($address)) {
    $updates[] = "address = ?";
    $types .= "s";
    $values[] = $address;
}

if (!empty($city)) {
    $updates[] = "city = ?";
    $types .= "s";
    $values[] = $city;
}

if (!empty($about)) {
    $updates[] = "about = ?";
    $types .= "s";
    $values[] = $about;
}

if (!empty($gst_number)) {
    $updates[] = "gst_number = ?";
    $types .= "s";
    $values[] = $gst_number;
}

if (!empty($company_size) && in_array($company_size, ['1-10', '11-50', '51-200', '200+'])) {
    $updates[] = "company_size = ?";
    $types .= "s";
    $values[] = $company_size;
}

// Add employer_id to values
$types .= "i";
$values[] = $employer_id;

$sql = "UPDATE employers SET " . implode(", ", $updates) . " WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$values);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "Profile updated successfully"]);
} else {
    echo json_encode(["success" => false, "message" => "Failed to update profile"]);
}

$stmt->close();
$conn->close();
?>
