<?php
error_reporting(0);
header('Content-Type: application/json');
include 'db.php';

// Get parameters
$user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;
$user_type = isset($_GET['user_type']) ? $_GET['user_type'] : '';
$other_id = isset($_GET['other_id']) ? intval($_GET['other_id']) : 0;
$other_type = isset($_GET['other_type']) ? $_GET['other_type'] : '';
$job_id = isset($_GET['job_id']) ? intval($_GET['job_id']) : null;

// Validate required fields
if ($user_id <= 0 || $other_id <= 0) {
    echo json_encode(["success" => false, "message" => "User IDs are required"]);
    exit;
}

if (!in_array($user_type, ['worker', 'employer']) || !in_array($other_type, ['worker', 'employer'])) {
    echo json_encode(["success" => false, "message" => "Invalid user types"]);
    exit;
}

// Build query to get messages between two users
$sql = "SELECT * FROM messages 
        WHERE ((sender_id = ? AND sender_type = ? AND receiver_id = ? AND receiver_type = ?)
           OR (sender_id = ? AND sender_type = ? AND receiver_id = ? AND receiver_type = ?))";
$params = [$user_id, $user_type, $other_id, $other_type, $other_id, $other_type, $user_id, $user_type];
$types = "isisisis";

// Filter by job if specified
if ($job_id) {
    $sql .= " AND job_id = ?";
    $params[] = $job_id;
    $types .= "i";
}

$sql .= " ORDER BY created_at ASC";

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

$messages = [];
while ($row = $result->fetch_assoc()) {
    $row['is_mine'] = ($row['sender_id'] == $user_id && $row['sender_type'] == $user_type);
    $messages[] = $row;
}

// Mark messages as read
$sql = "UPDATE messages SET is_read = 1 
        WHERE receiver_id = ? AND receiver_type = ? 
        AND sender_id = ? AND sender_type = ? AND is_read = 0";
$stmt2 = $conn->prepare($sql);
$stmt2->bind_param("isis", $user_id, $user_type, $other_id, $other_type);
$stmt2->execute();

echo json_encode([
    "success" => true,
    "count" => count($messages),
    "messages" => $messages
]);

$stmt->close();
$conn->close();
?>
