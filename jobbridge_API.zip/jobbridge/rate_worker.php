<?php
error_reporting(0);
header('Content-Type: application/json');
include "db.php";

$employer_id = isset($_POST['employer_id']) ? intval($_POST['employer_id']) : 0;
$worker_id = isset($_POST['worker_id']) ? intval($_POST['worker_id']) : 0;
$job_id = isset($_POST['job_id']) ? intval($_POST['job_id']) : 0;
$rating = isset($_POST['rating']) ? intval($_POST['rating']) : 0;
$review = isset($_POST['review']) ? trim($_POST['review']) : '';

if ($employer_id <= 0 || $worker_id <= 0 || $job_id <= 0) {
    echo json_encode(["success" => false, "message" => "Invalid parameters"]);
    exit;
}

if ($rating < 1 || $rating > 5) {
    echo json_encode(["success" => false, "message" => "Rating must be between 1 and 5"]);
    exit;
}

// Check if already rated
$checkStmt = $conn->prepare("SELECT id FROM worker_ratings WHERE employer_id = ? AND worker_id = ? AND job_id = ?");
$checkStmt->bind_param("iii", $employer_id, $worker_id, $job_id);
$checkStmt->execute();
if ($checkStmt->get_result()->num_rows > 0) {
    echo json_encode(["success" => false, "message" => "You have already rated this worker for this job"]);
    $checkStmt->close();
    exit;
}
$checkStmt->close();

$stmt = $conn->prepare("INSERT INTO worker_ratings (employer_id, worker_id, job_id, rating, review) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("iiiis", $employer_id, $worker_id, $job_id, $rating, $review);

if ($stmt->execute()) {
    $rating_id = $stmt->insert_id;
    
    // Get job title for notifications
    $jobStmt = $conn->prepare("SELECT title FROM jobs WHERE id = ?");
    $jobStmt->bind_param("i", $job_id);
    $jobStmt->execute();
    $jobResult = $jobStmt->get_result()->fetch_assoc();
    $jobTitle = $jobResult ? $jobResult['title'] : 'a job';
    $jobStmt->close();
    
    // Notify worker with rating details
    $workerMessage = "You received a $rating-star rating for '$jobTitle'.";
    if (!empty($review)) {
        $workerMessage .= " Review: \"" . substr($review, 0, 100) . "\"";
    }
    $notifStmt = $conn->prepare("INSERT INTO notifications (user_id, user_type, title, message, type, reference_id) VALUES (?, 'worker', 'New Rating Received', ?, 'rating', ?)");
    $notifStmt->bind_param("isi", $worker_id, $workerMessage, $rating_id);
    $notifStmt->execute();
    $notifStmt->close();
    
    // Notify employer confirming their rating was submitted
    $employerMessage = "Your $rating-star rating for the worker has been submitted for '$jobTitle'.";
    $empNotifStmt = $conn->prepare("INSERT INTO notifications (user_id, user_type, title, message, type, reference_id) VALUES (?, 'employer', 'Rating Submitted', ?, 'rating', ?)");
    $empNotifStmt->bind_param("isi", $employer_id, $employerMessage, $rating_id);
    $empNotifStmt->execute();
    $empNotifStmt->close();
    
    // Send push notifications to both
    require_once 'send_push_notification.php';
    sendPushToUser($conn, $worker_id, 'worker', 'New Rating Received', $workerMessage, 'rating');
    sendPushToUser($conn, $employer_id, 'employer', 'Rating Submitted', $employerMessage, 'rating');
    
    echo json_encode(["success" => true, "message" => "Rating submitted successfully"]);
} else {
    echo json_encode(["success" => false, "message" => "Failed to submit rating"]);
}

$stmt->close();
$conn->close();
?>
