<?php
error_reporting(0);
header('Content-Type: application/json');
include 'db.php';

// Get POST data
$data = json_decode(file_get_contents("php://input"), true);

$worker_id = isset($data['worker_id']) ? intval($data['worker_id']) : 0;
$employer_id = isset($data['employer_id']) ? intval($data['employer_id']) : 0;
$job_id = isset($data['job_id']) ? intval($data['job_id']) : 0;
$rating = isset($data['rating']) ? intval($data['rating']) : 0;
$review = isset($data['review']) ? trim($data['review']) : '';

// Validate required fields
if ($worker_id <= 0 || $employer_id <= 0 || $job_id <= 0) {
    echo json_encode(["success" => false, "message" => "Worker ID, Employer ID, and Job ID are required"]);
    exit;
}

if ($rating < 1 || $rating > 5) {
    echo json_encode(["success" => false, "message" => "Rating must be between 1 and 5"]);
    exit;
}

// Check if worker completed this job
$sql = "SELECT * FROM work_history WHERE worker_id = ? AND job_id = ? AND status = 'completed'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $worker_id, $job_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(["success" => false, "message" => "You can only rate employers for completed jobs"]);
    exit;
}
$stmt->close();

// Check if already rated
$sql = "SELECT * FROM employer_ratings WHERE worker_id = ? AND employer_id = ? AND job_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("iii", $worker_id, $employer_id, $job_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo json_encode(["success" => false, "message" => "You have already rated this employer for this job"]);
    exit;
}
$stmt->close();

// Insert rating
$sql = "INSERT INTO employer_ratings (employer_id, worker_id, job_id, rating, review) VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("iiiis", $employer_id, $worker_id, $job_id, $rating, $review);

if ($stmt->execute()) {
    $rating_id = $stmt->insert_id;
    
    // Get job title for notifications
    $jobStmt = $conn->prepare("SELECT title FROM jobs WHERE id = ?");
    $jobStmt->bind_param("i", $job_id);
    $jobStmt->execute();
    $jobResult = $jobStmt->get_result()->fetch_assoc();
    $jobTitle = $jobResult ? $jobResult['title'] : 'a job';
    $jobStmt->close();
    
    // Update employer's average rating
    $sql = "SELECT AVG(rating) as avg_rating, COUNT(*) as review_count FROM employer_ratings WHERE employer_id = ?";
    $stmt2 = $conn->prepare($sql);
    $stmt2->bind_param("i", $employer_id);
    $stmt2->execute();
    $result = $stmt2->get_result();
    $rating_data = $result->fetch_assoc();
    
    // Send notification to employer with rating details
    $notif_title = "New Rating Received";
    $notif_message = "You received a $rating-star rating for '$jobTitle'.";
    if (!empty($review)) {
        $notif_message .= " Review: \"" . substr($review, 0, 100) . "\"";
    }
    $sql = "INSERT INTO notifications (user_id, user_type, title, message, type, reference_id) VALUES (?, 'employer', ?, ?, 'rating', ?)";
    $stmt3 = $conn->prepare($sql);
    $stmt3->bind_param("issi", $employer_id, $notif_title, $notif_message, $rating_id);
    $stmt3->execute();
    
    // Send confirmation notification to worker
    $workerConfirmMsg = "Your $rating-star rating for the employer has been submitted for '$jobTitle'.";
    $stmt4 = $conn->prepare("INSERT INTO notifications (user_id, user_type, title, message, type, reference_id) VALUES (?, 'worker', 'Rating Submitted', ?, 'rating', ?)");
    $stmt4->bind_param("isi", $worker_id, $workerConfirmMsg, $rating_id);
    $stmt4->execute();
    
    // Send push notifications to both
    require_once 'send_push_notification.php';
    sendPushToUser($conn, $employer_id, 'employer', $notif_title, $notif_message, 'rating');
    sendPushToUser($conn, $worker_id, 'worker', 'Rating Submitted', $workerConfirmMsg, 'rating');
    
    echo json_encode([
        "success" => true, 
        "message" => "Rating submitted successfully",
        "new_avg_rating" => round($rating_data['avg_rating'], 1),
        "total_reviews" => $rating_data['review_count']
    ]);
} else {
    echo json_encode(["success" => false, "message" => "Failed to submit rating"]);
}

$stmt->close();
$conn->close();
?>
