<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
header('Content-Type: application/json');
include 'db.php';

// Get POST data
$data = json_decode(file_get_contents("php://input"), true);

$application_id = isset($data['application_id']) ? intval($data['application_id']) : 0;
$worker_id = isset($data['worker_id']) ? intval($data['worker_id']) : 0;

if ($application_id <= 0 || $worker_id <= 0) {
    echo json_encode(["success" => false, "message" => "Application ID and Worker ID are required"]);
    exit;
}

// Verify the application belongs to the worker and can be withdrawn
// Allow withdraw for 'applied', 'pending', or 'reviewed' status (not accepted/rejected/withdrawn)
$sql = "SELECT a.*, j.title as job_title, j.employer_id 
        FROM applications a 
        JOIN jobs j ON a.job_id = j.id 
        WHERE a.id = ? AND a.user_id = ? AND a.status IN ('applied', 'pending', 'reviewed')";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $application_id, $worker_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(["success" => false, "message" => "Application not found or cannot be withdrawn"]);
    exit;
}

$application = $result->fetch_assoc();
$stmt->close();

// Update status to withdrawn instead of deleting
$sql = "UPDATE applications SET status = 'withdrawn' WHERE id = ? AND user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $application_id, $worker_id);

if ($stmt->execute()) {
    // Notify worker
    $workerMsg = "You have withdrawn your application for '" . $application['job_title'] . "'.";
    $notifStmt = $conn->prepare("INSERT INTO notifications (user_id, user_type, title, message, type, reference_id) VALUES (?, 'worker', 'Application Withdrawn', ?, 'application_update', ?)");
    $notifStmt->bind_param("isi", $worker_id, $workerMsg, $application_id);
    $notifStmt->execute();
    $notifStmt->close();
    
    // Notify employer
    if ($application['employer_id']) {
        $employerMsg = "An applicant has withdrawn their application for '" . $application['job_title'] . "'.";
        $empNotifStmt = $conn->prepare("INSERT INTO notifications (user_id, user_type, title, message, type, reference_id) VALUES (?, 'employer', 'Application Withdrawn', ?, 'application_update', ?)");
        $empNotifStmt->bind_param("isi", $application['employer_id'], $employerMsg, $application_id);
        $empNotifStmt->execute();
        $empNotifStmt->close();
    }
    
    echo json_encode(["success" => true, "message" => "Application withdrawn successfully"]);
} else {
    echo json_encode(["success" => false, "message" => "Failed to withdraw application"]);
}

$stmt->close();
$conn->close();
?>
