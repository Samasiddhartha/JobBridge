<?php
error_reporting(0);
header('Content-Type: application/json');
include "db.php";

$job_id = isset($_GET['job_id']) ? intval($_GET['job_id']) : 0;

if ($job_id <= 0) {
    echo json_encode(["success" => false, "message" => "Invalid job ID"]);
    exit;
}

$stmt = $conn->prepare("
    SELECT a.id as application_id, a.user_id as worker_id, a.status, a.applied_at, a.cover_letter,
           w.name, w.mobile, w.profile_photo, w.address, w.city,
           wp.skills, wp.experience, wp.hourly_rate, wp.bio,
           (SELECT AVG(rating) FROM worker_ratings WHERE worker_id = w.id) as avg_rating,
           (SELECT COUNT(*) FROM worker_ratings WHERE worker_id = w.id) as total_reviews
    FROM applications a
    INNER JOIN workers w ON a.user_id = w.id
    LEFT JOIN worker_profiles wp ON w.id = wp.worker_id
    WHERE a.job_id = ?
    ORDER BY a.applied_at DESC
");
$stmt->bind_param("i", $job_id);
$stmt->execute();
$result = $stmt->get_result();

$applicants = [];
while ($row = $result->fetch_assoc()) {
    $applicants[] = [
        "application_id" => (int)$row['application_id'],
        "worker_id" => (int)$row['worker_id'],
        "name" => $row['name'],
        "mobile" => $row['mobile'],
        "profile_photo" => $row['profile_photo'],
        "address" => $row['address'],
        "city" => $row['city'],
        "skills" => $row['skills'],
        "experience" => (int)$row['experience'],
        "hourly_rate" => (int)$row['hourly_rate'],
        "bio" => $row['bio'],
        "avg_rating" => round((float)$row['avg_rating'], 1),
        "total_reviews" => (int)$row['total_reviews'],
        "status" => $row['status'],
        "applied_at" => $row['applied_at'],
        "cover_letter" => $row['cover_letter']
    ];
}

echo json_encode([
    "success" => true,
    "count" => count($applicants),
    "applicants" => $applicants
]);

$stmt->close();
$conn->close();
?>
