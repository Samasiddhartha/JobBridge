<?php
error_reporting(0);
header('Content-Type: application/json');
include "db.php";

// Get POST data - support both mobile (workers) and email (employers)
$mobile = isset($_POST['mobile']) ? trim($_POST['mobile']) : '';
$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$user_type = isset($_POST['user_type']) ? trim($_POST['user_type']) : '';

// Validate input
if (empty($mobile) && empty($email)) {
    echo json_encode([
        "success" => false,
        "message" => "Mobile number or email is required"
    ]);
    exit;
}

$user = null;
$identifier = '';
$detected_user_type = '';

// Check workers table first if mobile provided
if (!empty($mobile)) {
    $stmt = $conn->prepare("SELECT id, name FROM workers WHERE mobile = ? LIMIT 1");
    $stmt->bind_param("s", $mobile);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $identifier = $mobile;
        $detected_user_type = 'worker';
    }
    $stmt->close();
}

// Check employers table if email provided or if mobile not found in workers
if ($user === null && !empty($email)) {
    $stmt = $conn->prepare("SELECT id, company_name as name, mobile FROM employers WHERE email = ? LIMIT 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $identifier = $email;
        $detected_user_type = 'employer';
    }
    $stmt->close();
}

// Also check employers by mobile if not found
if ($user === null && !empty($mobile)) {
    $stmt = $conn->prepare("SELECT id, company_name as name, email FROM employers WHERE mobile = ? LIMIT 1");
    $stmt->bind_param("s", $mobile);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $identifier = $mobile;
        $detected_user_type = 'employer';
    }
    $stmt->close();
}

if ($user === null) {
    echo json_encode([
        "success" => false,
        "message" => "Account not found with the provided details"
    ]);
    exit;
}

// Generate 6-digit OTP
$otp = sprintf("%06d", mt_rand(0, 999999));

// Set expiry time (10 minutes from now)
$expiresAt = date('Y-m-d H:i:s', strtotime('+10 minutes'));

// Invalidate any existing OTPs for this identifier
$invalidateStmt = $conn->prepare("UPDATE otp_codes SET is_used = 1 WHERE mobile = ? AND is_used = 0");
$invalidateStmt->bind_param("s", $identifier);
$invalidateStmt->execute();
$invalidateStmt->close();

// Insert new OTP (store user_type in purpose field for tracking)
$purpose = 'forgot_password_' . $detected_user_type;
$insertStmt = $conn->prepare("INSERT INTO otp_codes (mobile, otp_code, purpose, expires_at) VALUES (?, ?, ?, ?)");
$insertStmt->bind_param("ssss", $identifier, $otp, $purpose, $expiresAt);

if ($insertStmt->execute()) {
    // In production, send OTP via SMS/Email here
    // For testing, we return the OTP in the response
    echo json_encode([
        "success" => true,
        "message" => "OTP sent successfully",
        "otp" => $otp, // Remove this in production
        "expires_in" => 600, // 10 minutes in seconds
        "user_name" => $user['name'],
        "user_type" => $detected_user_type
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Failed to generate OTP"
    ]);
}

$insertStmt->close();
$conn->close();
?>
