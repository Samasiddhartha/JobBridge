<?php
error_reporting(0);
header('Content-Type: application/json');
include "db.php";

$notification_id = isset($_POST['notification_id']) ? intval($_POST['notification_id']) : 0;
$user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
$mark_all = isset($_POST['mark_all']) ? $_POST['mark_all'] === 'true' : false;

if ($mark_all && $user_id > 0) {
    $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->close();
    
    echo json_encode(["success" => true, "message" => "All notifications marked as read"]);
} else if ($notification_id > 0) {
    $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE id = ?");
    $stmt->bind_param("i", $notification_id);
    $stmt->execute();
    $stmt->close();
    
    echo json_encode(["success" => true, "message" => "Notification marked as read"]);
} else {
    echo json_encode(["success" => false, "message" => "Invalid parameters"]);
}

$conn->close();
?>
