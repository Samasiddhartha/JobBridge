<?php
error_reporting(0);
header('Content-Type: application/json');
include "db.php";

$sql = "SELECT j.id, j.title, j.description, j.price_per_hour, 
               j.employer_id, j.employer_name, j.employer_rating, j.reviews_count,
               j.latitude, j.longitude, j.location_text, j.category, 
               j.job_type, j.shift_start, j.shift_end, j.urgency,
               j.min_experience, j.required_skills, j.benefits, j.openings, j.duration_hours,
               j.posted_at, j.status,
               (SELECT COUNT(*) FROM applications a WHERE a.job_id = j.id) as applicant_count
        FROM jobs j 
        WHERE j.status = 'active' 
        ORDER BY j.posted_at DESC";

$result = mysqli_query($conn, $sql);

$jobs = [];
while($row = mysqli_fetch_assoc($result)) {
    $jobs[] = $row;
}

echo json_encode([
    "success" => true,
    "count" => count($jobs),
    "jobs" => $jobs
]);
?>
