<?php
/**
 * Get detailed notification information based on type
 * Returns full context for job applications, status changes, ratings, etc.
 */

error_reporting(0);
header('Content-Type: application/json');
include "db.php";

$notification_id = isset($_GET['notification_id']) ? intval($_GET['notification_id']) : 0;

if ($notification_id <= 0) {
    echo json_encode(["success" => false, "message" => "Invalid notification ID"]);
    exit;
}

// Get notification basic info
$stmt = $conn->prepare("SELECT * FROM notifications WHERE id = ?");
$stmt->bind_param("i", $notification_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo json_encode(["success" => false, "message" => "Notification not found"]);
    exit;
}

$notification = $result->fetch_assoc();
$stmt->close();

$response = [
    "success" => true,
    "notification" => $notification,
    "details" => null
];

// Get additional details based on notification type
$type = $notification['type'];
$referenceId = isset($notification['reference_id']) ? intval($notification['reference_id']) : 0;

switch ($type) {
    case 'application_update':
    case 'application':
        // Get job and applicant details from message parsing or reference
        // Try to extract job info from related applications
        if ($referenceId > 0) {
            $detailStmt = $conn->prepare("
                SELECT 
                    a.id as application_id,
                    a.status,
                    a.created_at as applied_at,
                    a.cover_letter,
                    j.id as job_id,
                    j.title as job_title,
                    j.description as job_description,
                    j.price_per_hour as salary_min,
                    j.price_per_hour as salary_max,
                    j.location_text as location,
                    j.job_type,
                    w.id as worker_id,
                    w.name as worker_name,
                    w.mobile as worker_mobile,
                    wp.skills as worker_skills,
                    wp.experience as worker_experience,
                    w.profile_photo as worker_photo,
                    e.id as employer_id,
                    e.company_name,
                    e.email as employer_email
                FROM applications a
                JOIN jobs j ON a.job_id = j.id
                JOIN workers w ON a.user_id = w.id
                LEFT JOIN worker_profiles wp ON w.id = wp.worker_id
                JOIN employers e ON j.employer_id = e.id
                WHERE a.id = ?
            ");
            $detailStmt->bind_param("i", $referenceId);
            $detailStmt->execute();
            $detailResult = $detailStmt->get_result();
            
            if ($detailResult->num_rows > 0) {
                $response['details'] = $detailResult->fetch_assoc();
                $response['details']['detail_type'] = 'application';
            }
            $detailStmt->close();
        }
        break;
        
    case 'rating':
        // Get rating details
        if ($referenceId > 0) {
            $detailStmt = $conn->prepare("
                SELECT 
                    r.id as rating_id,
                    r.rating,
                    r.review,
                    r.created_at as rated_at,
                    j.title as job_title,
                    w.name as worker_name,
                    e.company_name as employer_name
                FROM ratings r
                LEFT JOIN jobs j ON r.job_id = j.id
                LEFT JOIN workers w ON r.worker_id = w.id
                LEFT JOIN employers e ON r.employer_id = e.id
                WHERE r.id = ?
            ");
            $detailStmt->bind_param("i", $referenceId);
            $detailStmt->execute();
            $detailResult = $detailStmt->get_result();
            
            if ($detailResult->num_rows > 0) {
                $response['details'] = $detailResult->fetch_assoc();
                $response['details']['detail_type'] = 'rating';
            }
            $detailStmt->close();
        }
        break;
        
    case 'system':
    case 'message':
        // Get message/conversation details
        if ($referenceId > 0) {
            $detailStmt = $conn->prepare("
                SELECT 
                    m.id as message_id,
                    m.message,
                    m.sender_id,
                    m.sender_type,
                    m.created_at as sent_at,
                    CASE 
                        WHEN m.sender_type = 'worker' THEN w.name
                        WHEN m.sender_type = 'employer' THEN e.company_name
                    END as sender_name
                FROM messages m
                LEFT JOIN workers w ON m.sender_id = w.id AND m.sender_type = 'worker'
                LEFT JOIN employers e ON m.sender_id = e.id AND m.sender_type = 'employer'
                WHERE m.id = ?
            ");
            $detailStmt->bind_param("i", $referenceId);
            $detailStmt->execute();
            $detailResult = $detailStmt->get_result();
            
            if ($detailResult->num_rows > 0) {
                $response['details'] = $detailResult->fetch_assoc();
                $response['details']['detail_type'] = 'message';
            }
            $detailStmt->close();
        }
        break;
}

$conn->close();
echo json_encode($response);
?>
