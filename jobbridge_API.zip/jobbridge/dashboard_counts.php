<?php
error_reporting(0);
header('Content-Type: application/json');
require_once "db.php";

$response = ["success" => false];

$worker_id = isset($_GET['worker_id']) ? intval($_GET['worker_id']) : 0;

if ($worker_id <= 0) {
    // Return general stats if no worker_id
    $sqlActive = "SELECT COUNT(*) AS c FROM jobs WHERE status='active'";
    $sqlCompleted = "SELECT COUNT(*) AS c FROM jobs WHERE status='completed'";
    $sqlPending = "SELECT COUNT(*) AS c FROM jobs WHERE status='active' AND posted_at > NOW() - INTERVAL 1 DAY";

    $active = $conn->query($sqlActive)->fetch_assoc()['c'];
    $completed = $conn->query($sqlCompleted)->fetch_assoc()['c'];
    $pending = $conn->query($sqlPending)->fetch_assoc()['c'];

    $response["success"] = true;
    $response["active"] = $active;
    $response["pending"] = $pending;
    $response["completed"] = $completed;
} else {
    // Return worker-specific dashboard data
    
    // Today's earnings (from completed jobs)
    $earningsQuery = "SELECT COALESCE(SUM(j.hourly_rate), 0) as earnings 
                      FROM applications a 
                      JOIN jobs j ON a.job_id = j.id 
                      WHERE a.user_id = ? AND a.status = 'completed' 
                      AND DATE(a.created_at) = CURDATE()";
    $stmt = $conn->prepare($earningsQuery);
    $stmt->bind_param("i", $worker_id);
    $stmt->execute();
    $earnings = $stmt->get_result()->fetch_assoc()['earnings'];
    $stmt->close();

    // Nearby jobs count (active jobs)
    $nearbyQuery = "SELECT COUNT(*) as count FROM jobs WHERE status = 'active'";
    $nearbyResult = $conn->query($nearbyQuery);
    $nearbyJobs = $nearbyResult->fetch_assoc()['count'];

    // Current active/accepted job
    $currentJobQuery = "SELECT j.id, j.title, j.location as distance, a.status as app_status
                        FROM applications a 
                        JOIN jobs j ON a.job_id = j.id 
                        WHERE a.user_id = ? AND a.status = 'accepted' AND j.status = 'active'
                        LIMIT 1";
    $stmt = $conn->prepare($currentJobQuery);
    $stmt->bind_param("i", $worker_id);
    $stmt->execute();
    $currentResult = $stmt->get_result();
    $currentJob = $currentResult->fetch_assoc();
    $stmt->close();

    // Application statistics for worker
    $appStatsQuery = "SELECT 
                        COUNT(*) as total_applications,
                        SUM(CASE WHEN status = 'applied' OR status = 'pending' THEN 1 ELSE 0 END) as pending_applications,
                        SUM(CASE WHEN status = 'accepted' THEN 1 ELSE 0 END) as accepted_applications,
                        SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected_applications,
                        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_jobs
                      FROM applications WHERE user_id = ?";
    $stmt = $conn->prepare($appStatsQuery);
    $stmt->bind_param("i", $worker_id);
    $stmt->execute();
    $appStats = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    $response["success"] = true;
    $response["today_earnings"] = (float)$earnings;
    $response["nearby_jobs"] = (int)$nearbyJobs;
    $response["current_job"] = $currentJob;
    
    // Worker application stats
    $response["total_applications"] = (int)$appStats['total_applications'];
    $response["pending_applications"] = (int)$appStats['pending_applications'];
    $response["accepted_applications"] = (int)$appStats['accepted_applications'];
    $response["rejected_applications"] = (int)$appStats['rejected_applications'];
    $response["completed_jobs"] = (int)$appStats['completed_jobs'];
}

$conn->close();
echo json_encode($response);
?>
