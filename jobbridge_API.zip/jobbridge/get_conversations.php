<?php
error_reporting(0);
header('Content-Type: application/json');
include 'db.php';

// Get parameters
$user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;
$user_type = isset($_GET['user_type']) ? $_GET['user_type'] : '';

// Validate required fields
if ($user_id <= 0) {
    echo json_encode(["success" => false, "message" => "User ID is required"]);
    exit;
}

if (!in_array($user_type, ['worker', 'employer'])) {
    echo json_encode(["success" => false, "message" => "Invalid user type"]);
    exit;
}

// Get all conversations for this user
// A conversation is uniquely identified by the combination of users and optionally a job
$sql = "SELECT 
            m.id,
            m.sender_id,
            m.sender_type,
            m.receiver_id,
            m.receiver_type,
            m.job_id,
            m.message as last_message,
            m.created_at as last_message_at,
            m.is_read,
            CASE 
                WHEN m.sender_id = ? AND m.sender_type = ? THEN m.receiver_id 
                ELSE m.sender_id 
            END as other_user_id,
            CASE 
                WHEN m.sender_id = ? AND m.sender_type = ? THEN m.receiver_type 
                ELSE m.sender_type 
            END as other_user_type
        FROM messages m
        WHERE m.id IN (
            SELECT MAX(id) FROM messages 
            WHERE (sender_id = ? AND sender_type = ?) OR (receiver_id = ? AND receiver_type = ?)
            GROUP BY 
                LEAST(sender_id, receiver_id),
                GREATEST(sender_id, receiver_id),
                sender_type,
                receiver_type,
                job_id
        )
        ORDER BY m.created_at DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("isisisis", $user_id, $user_type, $user_id, $user_type, $user_id, $user_type, $user_id, $user_type);
$stmt->execute();
$result = $stmt->get_result();

$conversations = [];
while ($row = $result->fetch_assoc()) {
    // Get the other user's name
    $other_id = $row['other_user_id'];
    $other_type = $row['other_user_type'];
    
    if ($other_type === 'worker') {
        $sql = "SELECT name, profile_photo FROM workers WHERE id = ?";
    } else {
        $sql = "SELECT company_name as name, profile_photo FROM employers WHERE id = ?";
    }
    $stmt2 = $conn->prepare($sql);
    $stmt2->bind_param("i", $other_id);
    $stmt2->execute();
    $user_result = $stmt2->get_result();
    
    if ($user_data = $user_result->fetch_assoc()) {
        $row['other_user_name'] = $user_data['name'];
        $row['other_user_photo'] = $user_data['profile_photo'];
    } else {
        $row['other_user_name'] = 'Unknown';
        $row['other_user_photo'] = null;
    }
    
    // Get job title if job_id exists
    if ($row['job_id']) {
        $sql = "SELECT title FROM jobs WHERE id = ?";
        $stmt3 = $conn->prepare($sql);
        $stmt3->bind_param("i", $row['job_id']);
        $stmt3->execute();
        $job_result = $stmt3->get_result();
        if ($job_data = $job_result->fetch_assoc()) {
            $row['job_title'] = $job_data['title'];
        }
    }
    
    // Get unread count
    $sql = "SELECT COUNT(*) as unread FROM messages 
            WHERE receiver_id = ? AND receiver_type = ? 
            AND sender_id = ? AND sender_type = ? 
            AND is_read = 0";
    $stmt4 = $conn->prepare($sql);
    $stmt4->bind_param("isis", $user_id, $user_type, $other_id, $other_type);
    $stmt4->execute();
    $unread_result = $stmt4->get_result();
    $unread_data = $unread_result->fetch_assoc();
    $row['unread_count'] = $unread_data['unread'];
    
    $conversations[] = $row;
}

echo json_encode([
    "success" => true,
    "count" => count($conversations),
    "conversations" => $conversations
]);

$stmt->close();
$conn->close();
?>
