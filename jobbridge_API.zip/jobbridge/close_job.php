<?php
error_reporting(0);
header('Content-Type: application/json');
include "db.php";

$job_id = isset($_POST['job_id']) ? intval($_POST['job_id']) : 0;
$status = isset($_POST['status']) ? trim($_POST['status']) : 'closed';

if ($job_id <= 0) {
    echo json_encode(["success" => false, "message" => "Invalid job ID"]);
    exit;
}

if (!in_array($status, ['active', 'closed', 'completed'])) {
    echo json_encode(["success" => false, "message" => "Invalid status"]);
    exit;
}

$stmt = $conn->prepare("UPDATE jobs SET status = ? WHERE id = ?");
$stmt->bind_param("si", $status, $job_id);

if ($stmt->execute()) {
    // If completing, update work history for accepted workers
    if ($status == 'completed') {
        $historyStmt = $conn->prepare("
            INSERT INTO work_history (worker_id, job_id, job_title, employer_name, status, total_earned)
            SELECT a.user_id, j.id, j.title, j.employer_name, 'completed', j.price_per_hour * 8
            FROM applications a
            JOIN jobs j ON a.job_id = j.id
            WHERE a.job_id = ? AND a.status = 'accepted'
        ");
        $historyStmt->bind_param("i", $job_id);
        $historyStmt->execute();
        $historyStmt->close();
    }
    
    echo json_encode(["success" => true, "message" => "Job status updated to " . $status]);
} else {
    echo json_encode(["success" => false, "message" => "Failed to update job status"]);
}

$stmt->close();
$conn->close();
?>
