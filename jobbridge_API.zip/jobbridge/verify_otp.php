<?php
error_reporting(0);
header('Content-Type: application/json');
include "db.php";

// Get POST data
$mobile = isset($_POST['mobile']) ? trim($_POST['mobile']) : '';
$otp = isset($_POST['otp']) ? trim($_POST['otp']) : '';

// Validate input
if (empty($mobile) || empty($otp)) {
    echo json_encode([
        "success" => false,
        "message" => "Mobile and OTP are required"
    ]);
    exit;
}

// Find valid OTP
$stmt = $conn->prepare("SELECT id, otp_code, expires_at FROM otp_codes WHERE mobile = ? AND otp_code = ? AND is_used = 0 AND purpose = 'forgot_password' ORDER BY created_at DESC LIMIT 1");
$stmt->bind_param("ss", $mobile, $otp);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    
    // Check if OTP has expired
    $expiresAt = strtotime($row['expires_at']);
    $currentTime = time();
    
    if ($currentTime > $expiresAt) {
        echo json_encode([
            "success" => false,
            "message" => "OTP has expired. Please request a new one"
        ]);
    } else {
        // OTP is valid - mark as verified but not used yet
        // It will be marked as used after password reset
        echo json_encode([
            "success" => true,
            "message" => "OTP verified successfully",
            "otp_id" => $row['id']
        ]);
    }
} else {
    echo json_encode([
        "success" => false,
        "message" => "Invalid OTP"
    ]);
}

$stmt->close();
$conn->close();
?>
