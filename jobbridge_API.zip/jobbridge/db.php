<?php
// Database connection configuration
error_reporting(0);

$host = "localhost";
$username = "root";
$password = "";
$database = "jobbridge";
$port = 3306;

$conn = mysqli_connect($host, $username, $password, $database, $port);

if (!$conn) {
    echo json_encode([
        "success" => false,
        "message" => "Database connection failed: " . mysqli_connect_error()
    ]);
    exit;
}

// Set charset to UTF-8
mysqli_set_charset($conn, "utf8mb4");
?>
