<?php
error_reporting(0);
header('Content-Type: application/json');
include "db.php";

$worker_id = isset($_GET['worker_id']) ? intval($_GET['worker_id']) : 0;

if ($worker_id <= 0) {
    echo json_encode(["success" => false, "message" => "Invalid worker ID"]);
    exit;
}

// Get all ratings for this worker
$stmt = $conn->prepare("
    SELECT r.id, r.rating, r.review, r.created_at,
           e.company_name as employer_name,
           j.title as job_title
    FROM worker_ratings r
    LEFT JOIN employers e ON r.employer_id = e.id
    LEFT JOIN jobs j ON r.job_id = j.id
    WHERE r.worker_id = ?
    ORDER BY r.created_at DESC
");
$stmt->bind_param("i", $worker_id);
$stmt->execute();
$result = $stmt->get_result();

$ratings = [];
$total_rating = 0;
$count = 0;
$distribution = [1 => 0, 2 => 0, 3 => 0, 4 => 0, 5 => 0];

while ($row = $result->fetch_assoc()) {
    $ratings[] = [
        "id" => (int)$row['id'],
        "rating" => (int)$row['rating'],
        "review" => $row['review'],
        "employer_name" => $row['employer_name'],
        "job_title" => $row['job_title'],
        "created_at" => $row['created_at']
    ];
    $total_rating += (int)$row['rating'];
    $distribution[(int)$row['rating']]++;
    $count++;
}

$avg_rating = $count > 0 ? round($total_rating / $count, 1) : 0;

echo json_encode([
    "success" => true,
    "summary" => [
        "average_rating" => $avg_rating,
        "total_reviews" => $count,
        "distribution" => $distribution
    ],
    "ratings" => $ratings
]);

$stmt->close();
$conn->close();
?>
