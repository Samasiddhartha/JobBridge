<?php
error_reporting(0);
header('Content-Type: application/json');
include "db.php";

$employer_id = isset($_GET['employer_id']) ? intval($_GET['employer_id']) : 0;
$status = isset($_GET['status']) ? trim($_GET['status']) : '';

if ($employer_id <= 0) {
    echo json_encode(["success" => false, "message" => "Invalid employer ID"]);
    exit;
}

$query = "SELECT j.id, j.title, j.description, j.price_per_hour, j.location_text, 
          j.category, j.status, j.posted_at,
          (SELECT COUNT(*) FROM applications WHERE job_id = j.id) as applicant_count,
          (SELECT COUNT(*) FROM applications WHERE job_id = j.id AND status = 'pending') as pending_count
          FROM jobs j 
          WHERE j.employer_id = ?";

$params = [$employer_id];
$types = "i";

if (!empty($status) && $status != 'all') {
    $query .= " AND j.status = ?";
    $params[] = $status;
    $types .= "s";
}

$query .= " ORDER BY j.posted_at DESC";

$stmt = $conn->prepare($query);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

$jobs = [];
$stats = ["total" => 0, "active" => 0, "closed" => 0, "completed" => 0];

while ($row = $result->fetch_assoc()) {
    $jobs[] = [
        "id" => (int)$row['id'],
        "title" => $row['title'],
        "description" => $row['description'],
        "price_per_hour" => (int)$row['price_per_hour'],
        "location_text" => $row['location_text'],
        "category" => $row['category'],
        "status" => $row['status'],
        "posted_at" => $row['posted_at'],
        "applicant_count" => (int)$row['applicant_count'],
        "pending_count" => (int)$row['pending_count']
    ];
    
    $stats["total"]++;
    if ($row['status'] == 'active') $stats["active"]++;
    elseif ($row['status'] == 'closed') $stats["closed"]++;
    elseif ($row['status'] == 'completed') $stats["completed"]++;
}

echo json_encode([
    "success" => true,
    "stats" => $stats,
    "jobs" => $jobs
]);

$stmt->close();
$conn->close();
?>
