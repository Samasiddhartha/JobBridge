<?php
error_reporting(0);
header('Content-Type: application/json');
include "db.php";

$user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;
$user_type = isset($_GET['user_type']) ? trim($_GET['user_type']) : 'worker';

if ($user_id <= 0) {
    echo json_encode(["success" => false, "message" => "Invalid user ID"]);
    exit;
}

$stmt = $conn->prepare("
    SELECT id, title, message, type, is_read, created_at 
    FROM notifications 
    WHERE user_id = ? AND user_type = ?
    ORDER BY created_at DESC
    LIMIT 50
");
$stmt->bind_param("is", $user_id, $user_type);
$stmt->execute();
$result = $stmt->get_result();

$notifications = [];
$unread_count = 0;

while ($row = $result->fetch_assoc()) {
    $notifications[] = [
        "id" => (int)$row['id'],
        "title" => $row['title'],
        "message" => $row['message'],
        "type" => $row['type'],
        "is_read" => (int)$row['is_read'],
        "created_at" => $row['created_at']
    ];
    if ($row['is_read'] == 0) $unread_count++;
}

echo json_encode([
    "success" => true,
    "unread_count" => $unread_count,
    "notifications" => $notifications
]);

$stmt->close();
$conn->close();
?>
