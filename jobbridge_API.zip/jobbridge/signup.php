<?php
error_reporting(0);
header('Content-Type: application/json');
include "db.php";

// Get POST data
$name = isset($_POST['name']) ? trim($_POST['name']) : '';
$mobile = isset($_POST['mobile']) ? trim($_POST['mobile']) : '';
$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';
$role = isset($_POST['role']) ? trim($_POST['role']) : '';

// Validate input
if (empty($name) || empty($mobile) || empty($password) || empty($role)) {
    echo json_encode([
        "success" => false,
        "message" => "All fields are required"
    ]);
    exit;
}

// Validate mobile number (10 digits)
if (!preg_match('/^[0-9]{10}$/', $mobile)) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid mobile number. Must be 10 digits"
    ]);
    exit;
}

// Validate password length
if (strlen($password) < 6) {
    echo json_encode([
        "success" => false,
        "message" => "Password must be at least 6 characters"
    ]);
    exit;
}

// Validate email if provided
if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid email format"
    ]);
    exit;
}

// Store password as plain text (for testing/academic purposes)
$plainPassword = $password;

if ($role == "Worker") {
    // Check if mobile already exists
    $checkStmt = $conn->prepare("SELECT id FROM workers WHERE mobile = ?");
    $checkStmt->bind_param("s", $mobile);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();
    
    if ($checkResult->num_rows > 0) {
        echo json_encode([
            "success" => false,
            "message" => "Mobile number already registered"
        ]);
        $checkStmt->close();
        exit;
    }
    $checkStmt->close();
    
    // Check if email already exists (if provided)
    if (!empty($email)) {
        $checkEmailStmt = $conn->prepare("SELECT id FROM workers WHERE email = ?");
        $checkEmailStmt->bind_param("s", $email);
        $checkEmailStmt->execute();
        $checkEmailResult = $checkEmailStmt->get_result();
        
        if ($checkEmailResult->num_rows > 0) {
            echo json_encode([
                "success" => false,
                "message" => "Email already registered"
            ]);
            $checkEmailStmt->close();
            exit;
        }
        $checkEmailStmt->close();
    }
    
    // Insert new worker with email
    $stmt = $conn->prepare("INSERT INTO workers (name, mobile, email, password) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $mobile, $email, $plainPassword);
    
    if ($stmt->execute()) {
        $insertId = $stmt->insert_id;
        
        // Also create worker profile entry
        $profileStmt = $conn->prepare("INSERT INTO worker_profiles (worker_id) VALUES (?)");
        $profileStmt->bind_param("i", $insertId);
        $profileStmt->execute();
        $profileStmt->close();
        
        echo json_encode([
            "success" => true,
            "message" => "Worker registration successful",
            "user_id" => $insertId
        ]);
    } else {
        echo json_encode([
            "success" => false,
            "message" => "Registration failed: " . $stmt->error
        ]);
    }
    $stmt->close();
    
} else if ($role == "Employer") {
    // For employers, 'name' is company name and 'mobile' can be email or phone
    $companyName = $name;
    
    // Check if it's an email
    if (filter_var($mobile, FILTER_VALIDATE_EMAIL)) {
        $employerEmail = $mobile;
        $employerMobile = '';
    } else {
        $employerEmail = $email;
        $employerMobile = $mobile;
    }
    
    // Validate email
    if (empty($employerEmail) || !filter_var($employerEmail, FILTER_VALIDATE_EMAIL)) {
        echo json_encode([
            "success" => false,
            "message" => "Valid email is required for employers"
        ]);
        exit;
    }
    
    // Check if email already exists
    $checkStmt = $conn->prepare("SELECT id FROM employers WHERE email = ?");
    $checkStmt->bind_param("s", $employerEmail);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();
    
    if ($checkResult->num_rows > 0) {
        echo json_encode([
            "success" => false,
            "message" => "Email already registered"
        ]);
        $checkStmt->close();
        exit;
    }
    $checkStmt->close();
    
    // Insert new employer
    $stmt = $conn->prepare("INSERT INTO employers (company_name, email, mobile, password) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $companyName, $employerEmail, $employerMobile, $plainPassword);
    
    if ($stmt->execute()) {
        $insertId = $stmt->insert_id;
        echo json_encode([
            "success" => true,
            "message" => "Employer registration successful",
            "user_id" => $insertId
        ]);
    } else {
        echo json_encode([
            "success" => false,
            "message" => "Registration failed: " . $stmt->error
        ]);
    }
    $stmt->close();
    
} else {
    echo json_encode([
        "success" => false,
        "message" => "Invalid role specified"
    ]);
}

$conn->close();
?>
