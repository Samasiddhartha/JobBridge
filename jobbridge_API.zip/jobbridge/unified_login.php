<?php
error_reporting(0);
header('Content-Type: application/json');
include "db.php";

// Get POST data
$identifier = isset($_POST['identifier']) ? trim($_POST['identifier']) : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';

// Validate input
if (empty($identifier) || empty($password)) {
    echo json_encode([
        "success" => false,
        "message" => "Email/Mobile and password are required"
    ]);
    exit;
}

// First, check workers table (by mobile or name)
$stmt = $conn->prepare("SELECT id, name, mobile, password FROM workers WHERE mobile = ? OR name = ? LIMIT 1");
$stmt->bind_param("ss", $identifier, $identifier);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    
    // Verify password
    $passwordValid = false;
    if (substr($row['password'], 0, 4) === '$2y$') {
        $passwordValid = password_verify($password, $row['password']);
    } else {
        $passwordValid = ($password === $row['password']);
    }
    
    if ($passwordValid) {
        $stmt->close();
        $conn->close();
        echo json_encode([
            "success" => true,
            "message" => "Login successful",
            "user_type" => "worker",
            "worker" => [
                "id" => (int)$row['id'],
                "name" => $row['name'],
                "mobile" => $row['mobile']
            ]
        ]);
        exit;
    } else {
        $stmt->close();
        $conn->close();
        echo json_encode([
            "success" => false,
            "message" => "Invalid password"
        ]);
        exit;
    }
}
$stmt->close();

// If not found in workers, check employers table (by email)
$stmt = $conn->prepare("SELECT id, company_name, email, password, is_verified FROM employers WHERE email = ? LIMIT 1");
$stmt->bind_param("s", $identifier);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    
    // Verify password
    $passwordValid = false;
    if (substr($row['password'], 0, 4) === '$2y$') {
        $passwordValid = password_verify($password, $row['password']);
    } else {
        $passwordValid = ($password === $row['password']);
    }
    
    if ($passwordValid) {
        $stmt->close();
        $conn->close();
        echo json_encode([
            "success" => true,
            "message" => "Login successful",
            "user_type" => "employer",
            "employer" => [
                "id" => (int)$row['id'],
                "company_name" => $row['company_name'],
                "email" => $row['email'],
                "is_verified" => (int)$row['is_verified']
            ]
        ]);
        exit;
    } else {
        $stmt->close();
        $conn->close();
        echo json_encode([
            "success" => false,
            "message" => "Invalid password"
        ]);
        exit;
    }
}

$stmt->close();
$conn->close();

// User not found in either table
echo json_encode([
    "success" => false,
    "message" => "User not found. Please check your credentials."
]);
?>
