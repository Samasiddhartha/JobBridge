<?php
ob_start();
error_reporting(0);
header('Content-Type: application/json; charset=utf-8');

include "db.php";

$response = ["success" => false, "message" => "Unknown error"];

try {
    $application_id = isset($_POST['application_id']) ? intval($_POST['application_id']) : 0;
    $status = isset($_POST['status']) ? trim($_POST['status']) : '';

    if ($application_id <= 0) {
        $response["message"] = "Invalid application ID";
        ob_end_clean();
        echo json_encode($response);
        exit;
    }

    if (!in_array($status, ['accepted', 'rejected', 'pending'])) {
        $response["message"] = "Invalid status";
        ob_end_clean();
        echo json_encode($response);
        exit;
    }

    // Check if connection is valid
    if (!$conn || $conn->connect_error) {
        $response["message"] = "Database connection failed";
        ob_end_clean();
        echo json_encode($response);
        exit;
    }

    $stmt = $conn->prepare("UPDATE applications SET status = ? WHERE id = ?");
    if (!$stmt) {
        $response["message"] = "Prepare failed: " . $conn->error;
        ob_end_clean();
        echo json_encode($response);
        exit;
    }
    
    $stmt->bind_param("si", $status, $application_id);

    if ($stmt->execute()) {
        // Get worker and job info for notification
        $infoStmt = $conn->prepare("
            SELECT a.user_id as worker_id, j.title as job_title 
            FROM applications a
            JOIN jobs j ON a.job_id = j.id
            WHERE a.id = ?
        ");
        
        if ($infoStmt) {
            $infoStmt->bind_param("i", $application_id);
            $infoStmt->execute();
            $info = $infoStmt->get_result()->fetch_assoc();
            $infoStmt->close();
            
            // Create notification for worker (optional - don't fail if this fails)
            if ($info && isset($info['worker_id'])) {
                $title = $status == 'accepted' ? "Application Accepted!" : "Application Update";
                $message = $status == 'accepted' 
                    ? "Congratulations! Your application for '" . $info['job_title'] . "' has been accepted."
                    : "Your application for '" . $info['job_title'] . "' has been " . $status . ".";
                
                $notifStmt = $conn->prepare("INSERT INTO notifications (user_id, user_type, title, message, type, reference_id) VALUES (?, 'worker', ?, ?, 'application_update', ?)");
                if ($notifStmt) {
                    $notifStmt->bind_param("issi", $info['worker_id'], $title, $message, $application_id);
                    $notifStmt->execute();
                    $notifStmt->close();
                    
                    // Send push notification
                    require_once 'send_push_notification.php';
                    sendPushToUser($conn, $info['worker_id'], 'worker', $title, $message, 'application');
                }
            }
        }
        
        $response["success"] = true;
        $response["message"] = "Application " . $status;
    } else {
        $response["message"] = "Failed to update: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();

} catch (Exception $e) {
    $response["message"] = "Error: " . $e->getMessage();
}

ob_end_clean();
echo json_encode($response);
?>
