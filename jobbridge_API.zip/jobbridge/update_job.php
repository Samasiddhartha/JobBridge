<?php
error_reporting(0);
header('Content-Type: application/json');
include "db.php";

$job_id = isset($_POST['job_id']) ? intval($_POST['job_id']) : 0;
$title = isset($_POST['title']) ? trim($_POST['title']) : '';
$description = isset($_POST['description']) ? trim($_POST['description']) : '';
$price_per_hour = isset($_POST['price_per_hour']) ? intval($_POST['price_per_hour']) : 0;
$location_text = isset($_POST['location_text']) ? trim($_POST['location_text']) : '';
$category = isset($_POST['category']) ? trim($_POST['category']) : '';

if ($job_id <= 0) {
    echo json_encode(["success" => false, "message" => "Invalid job ID"]);
    exit;
}

if (empty($title)) {
    echo json_encode(["success" => false, "message" => "Title is required"]);
    exit;
}

$stmt = $conn->prepare("UPDATE jobs SET title = ?, description = ?, price_per_hour = ?, location_text = ?, category = ? WHERE id = ?");
$stmt->bind_param("ssissi", $title, $description, $price_per_hour, $location_text, $category, $job_id);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "Job updated successfully"]);
} else {
    echo json_encode(["success" => false, "message" => "Failed to update job"]);
}

$stmt->close();
$conn->close();
?>
