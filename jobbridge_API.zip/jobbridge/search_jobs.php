<?php
error_reporting(0);
header('Content-Type: application/json');
include 'db.php';

// Search jobs with filters
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$category = isset($_GET['category']) ? $_GET['category'] : '';
$job_type = isset($_GET['job_type']) ? $_GET['job_type'] : '';
$min_wage = isset($_GET['min_wage']) ? intval($_GET['min_wage']) : 0;
$max_wage = isset($_GET['max_wage']) ? intval($_GET['max_wage']) : 0;
$city = isset($_GET['city']) ? trim($_GET['city']) : '';
$urgency = isset($_GET['urgency']) ? $_GET['urgency'] : '';

// Base query
$sql = "SELECT j.*, 
        (SELECT COUNT(*) FROM applications a WHERE a.job_id = j.id) as applicant_count
        FROM jobs j WHERE j.status = 'active'";
$params = [];
$types = "";

// Add search condition (title, description, category)
if (!empty($search)) {
    $sql .= " AND (j.title LIKE ? OR j.description LIKE ? OR j.category LIKE ?)";
    $searchTerm = "%$search%";
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $types .= "sss";
}

// Filter by category
if (!empty($category)) {
    $sql .= " AND j.category = ?";
    $params[] = $category;
    $types .= "s";
}

// Filter by job type
if (!empty($job_type)) {
    $sql .= " AND j.job_type = ?";
    $params[] = $job_type;
    $types .= "s";
}

// Filter by wage range
if ($min_wage > 0) {
    $sql .= " AND j.price_per_hour >= ?";
    $params[] = $min_wage;
    $types .= "i";
}
if ($max_wage > 0) {
    $sql .= " AND j.price_per_hour <= ?";
    $params[] = $max_wage;
    $types .= "i";
}

// Filter by city
if (!empty($city)) {
    $sql .= " AND j.location_text LIKE ?";
    $params[] = "%$city%";
    $types .= "s";
}

// Filter by urgency
if (!empty($urgency)) {
    $sql .= " AND j.urgency = ?";
    $params[] = $urgency;
    $types .= "s";
}

// Order by posted date
$sql .= " ORDER BY j.posted_at DESC";

// Prepare and execute
$stmt = $conn->prepare($sql);

if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

$jobs = [];
while ($row = $result->fetch_assoc()) {
    $jobs[] = $row;
}

echo json_encode([
    "success" => true,
    "count" => count($jobs),
    "jobs" => $jobs
]);

$stmt->close();
$conn->close();
?>
