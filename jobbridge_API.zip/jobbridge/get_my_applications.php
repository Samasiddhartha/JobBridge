<?php
error_reporting(0);
header('Content-Type: application/json');
header("Content-Type: application/json");
require_once "db.php";

$response = ["success" => false, "applications" => []];

// Accept both worker_id and user_id for compatibility
$worker_id = isset($_GET['worker_id']) ? intval($_GET['worker_id']) : 
             (isset($_GET['user_id']) ? intval($_GET['user_id']) : 0);
$status = isset($_GET['status']) ? $_GET['status'] : null;

if ($worker_id == 0) {
    echo json_encode(["success" => false, "message" => "Missing worker_id"]);
    exit;
}

// Build query - user_id is the column name in applications table
$sql = "SELECT 
            a.id,
            a.status,
            a.applied_at,
            a.cover_letter,
            j.id AS job_id,
            j.title AS job_title,
            j.location_text AS location,
            j.price_per_hour,
            j.job_type,
            j.status AS job_status,
            e.company_name,
            e.profile_photo AS company_logo
        FROM applications a
        JOIN jobs j ON a.job_id = j.id
        LEFT JOIN employers e ON j.employer_id = e.id
        WHERE a.user_id = ?";

if ($status) {
    $sql .= " AND a.status = ?";
}

$sql .= " ORDER BY a.applied_at DESC";

$stmt = $conn->prepare($sql);

if ($status) {
    $stmt->bind_param("is", $worker_id, $status);
} else {
    $stmt->bind_param("i", $worker_id);
}

$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $response["applications"][] = [
        "application_id" => (int)$row["id"],
        "job_id" => (int)$row["job_id"],
        "job_title" => $row["job_title"],
        "company_name" => $row["company_name"] ?? "Unknown Company",
        "company_logo" => $row["company_logo"],
        "location" => $row["location"] ?? "",
        "wage" => "$" . $row["price_per_hour"] . "/hr",
        "job_type" => $row["job_type"],
        "job_status" => $row["job_status"],
        "status" => $row["status"],
        "applied_at" => $row["applied_at"],
        "cover_letter" => $row["cover_letter"]
    ];
}

$response["success"] = true;
$response["total"] = count($response["applications"]);
echo json_encode($response);

$stmt->close();
$conn->close();
?>
