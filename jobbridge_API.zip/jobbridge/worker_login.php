<?php
error_reporting(0);
header('Content-Type: application/json');
include "db.php";

// Get POST data
$mobile = isset($_POST['mobile']) ? trim($_POST['mobile']) : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';

// Validate input
if (empty($mobile) || empty($password)) {
    echo json_encode([
        "success" => false,
        "message" => "Mobile and password are required"
    ]);
    exit;
}

// Find user by mobile or name (email)
$stmt = $conn->prepare("SELECT id, name, mobile, password FROM workers WHERE mobile = ? OR name = ? LIMIT 1");
$stmt->bind_param("ss", $mobile, $mobile);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    
    // Verify password
    // Support both hashed and plain text passwords during migration
    $passwordValid = false;
    
    // Check if password is hashed (starts with $2y$)
    if (substr($row['password'], 0, 4) === '$2y$') {
        $passwordValid = password_verify($password, $row['password']);
    } else {
        // Plain text comparison (for old accounts - will be deprecated)
        $passwordValid = ($password === $row['password']);
    }
    
    if ($passwordValid) {
        echo json_encode([
            "success" => true,
            "message" => "Login successful",
            "worker" => [
                "id" => (int)$row['id'],
                "name" => $row['name'],
                "mobile" => $row['mobile']
            ]
        ]);
    } else {
        echo json_encode([
            "success" => false,
            "message" => "Invalid password"
        ]);
    }
} else {
    echo json_encode([
        "success" => false,
        "message" => "User not found"
    ]);
}

$stmt->close();
$conn->close();
?>
