<?php
error_reporting(0);
header('Content-Type: application/json');
include "db.php";

$worker_id = isset($_GET['worker_id']) ? intval($_GET['worker_id']) : 0;

if ($worker_id <= 0) {
    echo json_encode(["success" => false, "message" => "Invalid worker ID"]);
    exit;
}

$stmt = $conn->prepare("
    SELECT j.id, j.title, j.description, j.price_per_hour, j.employer_name, 
           j.employer_rating, j.reviews_count, j.location_text, j.category, 
           j.posted_at, s.saved_at
    FROM saved_jobs s
    INNER JOIN jobs j ON s.job_id = j.id
    WHERE s.worker_id = ?
    ORDER BY s.saved_at DESC
");
$stmt->bind_param("i", $worker_id);
$stmt->execute();
$result = $stmt->get_result();

$jobs = [];
while ($row = $result->fetch_assoc()) {
    $jobs[] = [
        "id" => (int)$row['id'],
        "title" => $row['title'],
        "description" => $row['description'],
        "price_per_hour" => (int)$row['price_per_hour'],
        "employer_name" => $row['employer_name'],
        "employer_rating" => (float)$row['employer_rating'],
        "reviews_count" => (int)$row['reviews_count'],
        "location_text" => $row['location_text'],
        "category" => $row['category'],
        "posted_at" => $row['posted_at'],
        "saved_at" => $row['saved_at']
    ];
}

echo json_encode([
    "success" => true,
    "count" => count($jobs),
    "jobs" => $jobs
]);

$stmt->close();
$conn->close();
?>
