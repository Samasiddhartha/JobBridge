<?php
error_reporting(0);
header('Content-Type: application/json');
include "db.php";

$employer_id = isset($_GET['employer_id']) ? intval($_GET['employer_id']) : 0;

if ($employer_id <= 0) {
    echo json_encode(["success" => false, "message" => "Invalid employer ID"]);
    exit;
}

// Get employer info with all fields
$stmt = $conn->prepare("
    SELECT id, company_name, email, mobile, profile_photo, 
           industry, company_size, website, gst_number,
           address, city, about, is_verified, created_at 
    FROM employers WHERE id = ?
");
$stmt->bind_param("i", $employer_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo json_encode(["success" => false, "message" => "Employer not found"]);
    $stmt->close();
    exit;
}

$employer = $result->fetch_assoc();
$stmt->close();

// Get rating stats
$ratingStmt = $conn->prepare("
    SELECT AVG(rating) as avg_rating, COUNT(*) as total_reviews 
    FROM employer_ratings WHERE employer_id = ?
");
$ratingStmt->bind_param("i", $employer_id);
$ratingStmt->execute();
$ratings = $ratingStmt->get_result()->fetch_assoc();
$ratingStmt->close();

// Get job stats
$statsStmt = $conn->prepare("
    SELECT 
        COUNT(*) as total_jobs,
        SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_jobs,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_jobs
    FROM jobs WHERE employer_id = ?
");
$statsStmt->bind_param("i", $employer_id);
$statsStmt->execute();
$stats = $statsStmt->get_result()->fetch_assoc();
$statsStmt->close();

// Get total hires
$hiresStmt = $conn->prepare("
    SELECT COUNT(*) as total_hires FROM applications a
    JOIN jobs j ON a.job_id = j.id
    WHERE j.employer_id = ? AND a.status = 'accepted'
");
$hiresStmt->bind_param("i", $employer_id);
$hiresStmt->execute();
$hires = $hiresStmt->get_result()->fetch_assoc();
$hiresStmt->close();

echo json_encode([
    "success" => true,
    "employer" => [
        "id" => (int)$employer['id'],
        "company_name" => $employer['company_name'],
        "email" => $employer['email'],
        "mobile" => $employer['mobile'],
        "profile_photo" => $employer['profile_photo'],
        "industry" => $employer['industry'],
        "company_size" => $employer['company_size'],
        "website" => $employer['website'],
        "gst_number" => $employer['gst_number'],
        "address" => $employer['address'],
        "city" => $employer['city'],
        "about" => $employer['about'],
        "is_verified" => (int)$employer['is_verified'],
        "avg_rating" => round((float)($ratings['avg_rating'] ?? 0), 1),
        "total_reviews" => (int)($ratings['total_reviews'] ?? 0),
        "member_since" => $employer['created_at']
    ],
    "stats" => [
        "total_jobs" => (int)($stats['total_jobs'] ?? 0),
        "active_jobs" => (int)($stats['active_jobs'] ?? 0),
        "completed_jobs" => (int)($stats['completed_jobs'] ?? 0),
        "total_hires" => (int)($hires['total_hires'] ?? 0)
    ]
]);

$conn->close();
?>
