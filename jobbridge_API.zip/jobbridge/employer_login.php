<?php
error_reporting(0);
header('Content-Type: application/json');
include "db.php";

// Get POST data
$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';

// Validate input
if (empty($email) || empty($password)) {
    echo json_encode([
        "success" => false,
        "message" => "Email and password are required"
    ]);
    exit;
}

// Find employer by email
$stmt = $conn->prepare("SELECT id, company_name, email, password, is_verified FROM employers WHERE email = ? LIMIT 1");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    
    // Verify password
    // Support both hashed and plain text passwords during migration
    $passwordValid = false;
    
    // Check if password is hashed (starts with $2y$)
    if (substr($row['password'], 0, 4) === '$2y$') {
        $passwordValid = password_verify($password, $row['password']);
    } else {
        // Plain text comparison (for old accounts - will be deprecated)
        $passwordValid = ($password === $row['password']);
    }
    
    if ($passwordValid) {
        echo json_encode([
            "success" => true,
            "message" => "Login successful",
            "employer" => [
                "id" => (int)$row['id'],
                "company_name" => $row['company_name'],
                "email" => $row['email'],
                "is_verified" => (int)$row['is_verified']
            ]
        ]);
    } else {
        echo json_encode([
            "success" => false,
            "message" => "Invalid password"
        ]);
    }
} else {
    echo json_encode([
        "success" => false,
        "message" => "Employer not found"
    ]);
}

$stmt->close();
$conn->close();
?>
