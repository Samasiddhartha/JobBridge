<?php
error_reporting(0);
header('Content-Type: application/json');
include 'db.php';

// Get worker ID
$worker_id = isset($_GET['worker_id']) ? intval($_GET['worker_id']) : 0;

if ($worker_id <= 0) {
    echo json_encode(["success" => false, "message" => "Worker ID is required"]);
    exit;
}

// Get worker basic info
$sql = "SELECT w.id, w.name, w.mobile, w.email, w.profile_photo, w.address, w.city, 
               w.date_of_birth, w.gender, w.languages, w.is_verified, w.created_at
        FROM workers w WHERE w.id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $worker_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(["success" => false, "message" => "Worker not found"]);
    exit;
}

$worker = $result->fetch_assoc();
$stmt->close();

// Get worker profile (skills, experience, rate)
$sql = "SELECT skills, experience, hourly_rate FROM worker_profiles WHERE worker_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $worker_id);
$stmt->execute();
$profile_result = $stmt->get_result();

if ($profile_result->num_rows > 0) {
    $profile = $profile_result->fetch_assoc();
    $worker['skills'] = $profile['skills'];
    $worker['experience'] = $profile['experience'];
    $worker['hourly_rate'] = $profile['hourly_rate'];
} else {
    $worker['skills'] = null;
    $worker['experience'] = 0;
    $worker['hourly_rate'] = 0;
}
$stmt->close();

// Get average rating and review count
$sql = "SELECT AVG(rating) as avg_rating, COUNT(*) as review_count 
        FROM worker_ratings WHERE worker_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $worker_id);
$stmt->execute();
$rating_result = $stmt->get_result();
$rating_data = $rating_result->fetch_assoc();

$worker['avg_rating'] = $rating_data['avg_rating'] ? round($rating_data['avg_rating'], 1) : 0;
$worker['review_count'] = $rating_data['review_count'] ?: 0;
$stmt->close();

// Get jobs completed count
$sql = "SELECT COUNT(*) as jobs_completed FROM work_history WHERE worker_id = ? AND status = 'completed'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $worker_id);
$stmt->execute();
$history_result = $stmt->get_result();
$history_data = $history_result->fetch_assoc();

$worker['jobs_completed'] = $history_data['jobs_completed'] ?: 0;
$stmt->close();

// Get total earnings
$sql = "SELECT SUM(total_earned) as total_earnings FROM work_history WHERE worker_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $worker_id);
$stmt->execute();
$earnings_result = $stmt->get_result();
$earnings_data = $earnings_result->fetch_assoc();

$worker['total_earnings'] = $earnings_data['total_earnings'] ?: 0;
$stmt->close();

// Get recent work history (last 5)
$sql = "SELECT wh.job_title, wh.employer_name, wh.start_date, wh.end_date, 
               wh.hours_worked, wh.total_earned, wh.status
        FROM work_history wh WHERE wh.worker_id = ? 
        ORDER BY wh.end_date DESC LIMIT 5";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $worker_id);
$stmt->execute();
$work_result = $stmt->get_result();

$work_history = [];
while ($row = $work_result->fetch_assoc()) {
    $work_history[] = $row;
}
$worker['recent_work'] = $work_history;
$stmt->close();

// Get recent ratings (last 5)
$sql = "SELECT wr.rating, wr.review, wr.created_at, e.company_name as employer_name, j.title as job_title
        FROM worker_ratings wr
        LEFT JOIN employers e ON wr.employer_id = e.id
        LEFT JOIN jobs j ON wr.job_id = j.id
        WHERE wr.worker_id = ?
        ORDER BY wr.created_at DESC LIMIT 5";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $worker_id);
$stmt->execute();
$ratings_result = $stmt->get_result();

$ratings = [];
while ($row = $ratings_result->fetch_assoc()) {
    $ratings[] = $row;
}
$worker['recent_ratings'] = $ratings;
$stmt->close();

echo json_encode([
    "success" => true,
    "worker" => $worker
]);

$conn->close();
?>
