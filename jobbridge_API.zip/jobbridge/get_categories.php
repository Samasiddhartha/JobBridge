<?php
error_reporting(0);
header('Content-Type: application/json');
include "db.php";

$stmt = $conn->prepare("SELECT id, name, icon FROM categories ORDER BY name ASC");
$stmt->execute();
$result = $stmt->get_result();

$categories = [];
while ($row = $result->fetch_assoc()) {
    $categories[] = [
        "id" => (int)$row['id'],
        "name" => $row['name'],
        "icon" => $row['icon']
    ];
}

echo json_encode([
    "success" => true,
    "categories" => $categories
]);

$stmt->close();
$conn->close();
?>
