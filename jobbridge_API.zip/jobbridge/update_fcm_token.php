<?php
/**
 * Update FCM Token for push notifications
 * Stores the device's Firebase Cloud Messaging token for a user
 */

require_once 'db_config.php';

header('Content-Type: application/json');

$user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
$user_type = isset($_POST['user_type']) ? $_POST['user_type'] : '';
$fcm_token = isset($_POST['fcm_token']) ? $_POST['fcm_token'] : '';

if ($user_id <= 0 || empty($user_type) || empty($fcm_token)) {
    echo json_encode(["success" => false, "message" => "Missing required parameters"]);
    exit;
}

// Determine which table to update
if ($user_type === 'worker') {
    $sql = "UPDATE workers SET fcm_token = ? WHERE id = ?";
} else if ($user_type === 'employer') {
    $sql = "UPDATE employers SET fcm_token = ? WHERE id = ?";
} else {
    echo json_encode(["success" => false, "message" => "Invalid user type"]);
    exit;
}

$stmt = $conn->prepare($sql);
$stmt->bind_param("si", $fcm_token, $user_id);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "FCM token updated successfully"]);
} else {
    echo json_encode(["success" => false, "message" => "Failed to update FCM token"]);
}

$stmt->close();
$conn->close();
?>
