<?php
error_reporting(0);
header('Content-Type: application/json');
include "db.php";

$worker_id = isset($_POST['worker_id']) ? intval($_POST['worker_id']) : 0;
$name = isset($_POST['name']) ? trim($_POST['name']) : '';
$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$skills = isset($_POST['skills']) ? trim($_POST['skills']) : '';
$experience = isset($_POST['experience']) ? intval($_POST['experience']) : 0;
$hourly_rate = isset($_POST['hourly_rate']) ? intval($_POST['hourly_rate']) : 0;

if ($worker_id <= 0) {
    echo json_encode(["success" => false, "message" => "Invalid worker ID"]);
    exit;
}

// Update worker basic info
$updateWorker = $conn->prepare("UPDATE workers SET name = ?, email = ? WHERE id = ?");
$updateWorker->bind_param("ssi", $name, $email, $worker_id);
$updateWorker->execute();
$updateWorker->close();

// Check if profile exists
$checkProfile = $conn->prepare("SELECT id FROM worker_profiles WHERE worker_id = ?");
$checkProfile->bind_param("i", $worker_id);
$checkProfile->execute();
$profileExists = $checkProfile->get_result()->num_rows > 0;
$checkProfile->close();

if ($profileExists) {
    // Update existing profile
    $updateProfile = $conn->prepare("UPDATE worker_profiles SET skills = ?, experience = ?, hourly_rate = ? WHERE worker_id = ?");
    $updateProfile->bind_param("siii", $skills, $experience, $hourly_rate, $worker_id);
    $updateProfile->execute();
    $updateProfile->close();
} else {
    // Insert new profile
    $insertProfile = $conn->prepare("INSERT INTO worker_profiles (worker_id, skills, experience, hourly_rate) VALUES (?, ?, ?, ?)");
    $insertProfile->bind_param("isii", $worker_id, $skills, $experience, $hourly_rate);
    $insertProfile->execute();
    $insertProfile->close();
}

echo json_encode([
    "success" => true,
    "message" => "Profile updated successfully"
]);

$conn->close();
?>
