<?php
error_reporting(0);
header('Content-Type: application/json');
include "db.php";

$category = isset($_GET['category']) ? trim($_GET['category']) : '';
$min_wage = isset($_GET['min_wage']) ? intval($_GET['min_wage']) : 0;
$max_wage = isset($_GET['max_wage']) ? intval($_GET['max_wage']) : 1000;
$latitude = isset($_GET['latitude']) ? floatval($_GET['latitude']) : 0;
$longitude = isset($_GET['longitude']) ? floatval($_GET['longitude']) : 0;
$radius_km = isset($_GET['radius']) ? floatval($_GET['radius']) : 50;

$query = "SELECT id, title, description, price_per_hour, employer_name, employer_rating, 
          reviews_count, latitude, longitude, location_text, category, posted_at, status,
          (6371 * acos(cos(radians(?)) * cos(radians(latitude)) * cos(radians(longitude) - radians(?)) + sin(radians(?)) * sin(radians(latitude)))) AS distance
          FROM jobs WHERE status = 'active' AND price_per_hour BETWEEN ? AND ?";

$params = [$latitude, $longitude, $latitude, $min_wage, $max_wage];
$types = "dddii";

if (!empty($category) && $category != 'All') {
    $query .= " AND category = ?";
    $params[] = $category;
    $types .= "s";
}

if ($latitude != 0 && $longitude != 0) {
    $query .= " HAVING distance <= ?";
    $params[] = $radius_km;
    $types .= "d";
}

$query .= " ORDER BY posted_at DESC";

$stmt = $conn->prepare($query);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

$jobs = [];
while ($row = $result->fetch_assoc()) {
    $jobs[] = [
        "id" => (int)$row['id'],
        "title" => $row['title'],
        "description" => $row['description'],
        "price_per_hour" => (int)$row['price_per_hour'],
        "employer_name" => $row['employer_name'],
        "employer_rating" => (float)$row['employer_rating'],
        "reviews_count" => (int)$row['reviews_count'],
        "latitude" => (float)$row['latitude'],
        "longitude" => (float)$row['longitude'],
        "location_text" => $row['location_text'],
        "category" => $row['category'],
        "posted_at" => $row['posted_at'],
        "distance" => isset($row['distance']) ? round($row['distance'], 1) : null
    ];
}

echo json_encode([
    "success" => true,
    "count" => count($jobs),
    "jobs" => $jobs
]);

$stmt->close();
$conn->close();
?>
