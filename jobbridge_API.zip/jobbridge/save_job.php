<?php
error_reporting(0);
header('Content-Type: application/json');
include "db.php";

$worker_id = isset($_POST['worker_id']) ? intval($_POST['worker_id']) : 0;
$job_id = isset($_POST['job_id']) ? intval($_POST['job_id']) : 0;
$action = isset($_POST['action']) ? trim($_POST['action']) : 'save';

if ($worker_id <= 0 || $job_id <= 0) {
    echo json_encode(["success" => false, "message" => "Invalid parameters"]);
    exit;
}

if ($action == 'save') {
    // Check if already saved
    $checkStmt = $conn->prepare("SELECT id FROM saved_jobs WHERE worker_id = ? AND job_id = ?");
    $checkStmt->bind_param("ii", $worker_id, $job_id);
    $checkStmt->execute();
    
    if ($checkStmt->get_result()->num_rows > 0) {
        echo json_encode(["success" => false, "message" => "Job already saved"]);
        $checkStmt->close();
        exit;
    }
    $checkStmt->close();
    
    // Save job
    $saveStmt = $conn->prepare("INSERT INTO saved_jobs (worker_id, job_id) VALUES (?, ?)");
    $saveStmt->bind_param("ii", $worker_id, $job_id);
    
    if ($saveStmt->execute()) {
        echo json_encode(["success" => true, "message" => "Job saved successfully"]);
    } else {
        echo json_encode(["success" => false, "message" => "Failed to save job"]);
    }
    $saveStmt->close();
    
} else if ($action == 'unsave') {
    $deleteStmt = $conn->prepare("DELETE FROM saved_jobs WHERE worker_id = ? AND job_id = ?");
    $deleteStmt->bind_param("ii", $worker_id, $job_id);
    
    if ($deleteStmt->execute()) {
        echo json_encode(["success" => true, "message" => "Job removed from saved"]);
    } else {
        echo json_encode(["success" => false, "message" => "Failed to remove job"]);
    }
    $deleteStmt->close();
}

$conn->close();
?>
