<?php
error_reporting(0);
header('Content-Type: application/json');
header("Content-Type: application/json");
require_once "db.php";

$response = ["success" => false];

if (!isset($_POST['job_id']) || !isset($_POST['user_id'])) {
    echo json_encode(["success" => false, "message" => "job_id and user_id required"]);
    exit;
}

$job_id = intval($_POST['job_id']);
$user_id = intval($_POST['user_id']);
$cover_letter = isset($_POST['cover_letter']) ? trim($_POST['cover_letter']) : null;
$expected_salary = isset($_POST['expected_salary']) ? intval($_POST['expected_salary']) : null;

// Check if already applied
$check = $conn->prepare("SELECT id FROM applications WHERE job_id=? AND user_id=?");
$check->bind_param("ii", $job_id, $user_id);
$check->execute();
$check->store_result();

if ($check->num_rows > 0) {
    echo json_encode(["success" => false, "message" => "Already applied to this job"]);
    exit;
}
$check->close();

// Check if job exists and is active
$jobCheck = $conn->prepare("SELECT id, employer_id, title FROM jobs WHERE id = ? AND status = 'active'");
$jobCheck->bind_param("i", $job_id);
$jobCheck->execute();
$jobResult = $jobCheck->get_result();

if ($jobResult->num_rows == 0) {
    echo json_encode(["success" => false, "message" => "Job not available"]);
    exit;
}
$job = $jobResult->fetch_assoc();
$jobCheck->close();

// Insert application
$stmt = $conn->prepare("INSERT INTO applications (job_id, user_id, cover_letter, expected_salary) VALUES (?, ?, ?, ?)");
$stmt->bind_param("iisi", $job_id, $user_id, $cover_letter, $expected_salary);

if ($stmt->execute()) {
    $application_id = $stmt->insert_id;
    
    // Create notification for employer with reference to application
    if ($job['employer_id']) {
        $notifStmt = $conn->prepare("
            INSERT INTO notifications (user_id, user_type, title, message, type, reference_id) 
            VALUES (?, 'employer', 'New Application', ?, 'application_update', ?)
        ");
        $notifMessage = "Someone applied for your job: " . $job['title'];
        $notifStmt->bind_param("isi", $job['employer_id'], $notifMessage, $application_id);
        $notifStmt->execute();
        $notifStmt->close();
        
        // Send push notification to employer
        require_once 'send_push_notification.php';
        sendPushToUser($conn, $job['employer_id'], 'employer', 'New Application', $notifMessage, 'application');
    }
    
    // Create notification for worker confirming their application
    $workerNotifStmt = $conn->prepare("
        INSERT INTO notifications (user_id, user_type, title, message, type, reference_id) 
        VALUES (?, 'worker', 'Application Submitted', ?, 'application_update', ?)
    ");
    $workerNotifMessage = "Your application for '" . $job['title'] . "' has been submitted successfully. We'll notify you when the employer responds.";
    $workerNotifStmt->bind_param("isi", $user_id, $workerNotifMessage, $application_id);
    $workerNotifStmt->execute();
    $workerNotifStmt->close();
    
    // Send push notification to worker
    sendPushToUser($conn, $user_id, 'worker', 'Application Submitted', $workerNotifMessage, 'application');
    
    $response["success"] = true;
    $response["message"] = "Application submitted successfully";
    $response["application_id"] = $application_id;
} else {
    $response["message"] = "Failed to submit application";
}

$stmt->close();
$conn->close();

echo json_encode($response);
?>
