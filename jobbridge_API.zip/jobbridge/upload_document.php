<?php
error_reporting(0);
header('Content-Type: application/json');

// Configuration
$base_upload_dir = "uploads/";
$max_size = 5 * 1024 * 1024; // 5MB

// Subdirectories for different document types
$subfolders = [
    'profile_photo' => 'profiles/',
    'company_logo' => 'logos/',
    'resume' => 'documents/',
    'id_proof' => 'documents/',
    'certificate' => 'documents/'
];

// Create upload directories if they don't exist
$directories = ['uploads/', 'uploads/profiles/', 'uploads/documents/', 'uploads/logos/'];
foreach ($directories as $dir) {
    if (!file_exists($dir)) {
        mkdir($dir, 0755, true);
    }
}

// Get common parameters
$user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 
           (isset($_POST['worker_id']) ? intval($_POST['worker_id']) : 
           (isset($_POST['employer_id']) ? intval($_POST['employer_id']) : 0));
$user_type = isset($_POST['user_type']) ? $_POST['user_type'] : 'worker';
$document_type = isset($_POST['document_type']) ? $_POST['document_type'] : 'profile_photo';

// Validate user_id
if ($user_id <= 0) {
    echo json_encode(["success" => false, "message" => "Invalid user ID"]);
    exit;
}

// Determine subfolder
$subfolder = isset($subfolders[$document_type]) ? $subfolders[$document_type] : 'documents/';
$upload_dir = $base_upload_dir . $subfolder;

// Create subfolder if needed
if (!file_exists($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

// Check if this is a Base64 upload
if (isset($_POST['file_data']) && !empty($_POST['file_data'])) {
    // Base64 upload
    $base64_data = $_POST['file_data'];
    $file_name = isset($_POST['file_name']) ? $_POST['file_name'] : 'file_' . time() . '.jpg';
    
    // Remove data URL prefix if present
    if (strpos($base64_data, 'base64,') !== false) {
        $base64_data = explode('base64,', $base64_data)[1];
    }
    
    // Decode base64
    $decoded_data = base64_decode($base64_data);
    if ($decoded_data === false) {
        echo json_encode(["success" => false, "message" => "Invalid base64 data"]);
        exit;
    }
    
    // Check size
    if (strlen($decoded_data) > $max_size) {
        echo json_encode(["success" => false, "message" => "File too large. Max 5MB allowed"]);
        exit;
    }
    
    // Generate unique filename
    $extension = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
    if (empty($extension)) {
        $extension = 'jpg';
    }
    $filename = $user_type . "_" . $user_id . "_" . $document_type . "_" . time() . "." . $extension;
    $filepath = $upload_dir . $filename;
    
    // Save file
    if (file_put_contents($filepath, $decoded_data)) {
        // Generate URL
        $protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https://' : 'http://';
        $host = $_SERVER['HTTP_HOST'];
        $file_url = $protocol . $host . "/jobbridge/" . $upload_dir . $filename;
        
        // Update database
        include 'db.php';
        
        if ($document_type === 'profile_photo' || $document_type === 'company_logo') {
            if ($user_type === 'worker') {
                $sql = "UPDATE workers SET profile_photo = ? WHERE id = ?";
            } else {
                $sql = "UPDATE employers SET profile_photo = ? WHERE id = ?";
            }
            
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("si", $file_url, $user_id);
            $stmt->execute();
            $stmt->close();
        }
        
        $conn->close();
        
        echo json_encode([
            "success" => true,
            "message" => "File uploaded successfully",
            "file_url" => $file_url,
            "filename" => $filename
        ]);
    } else {
        echo json_encode(["success" => false, "message" => "Failed to save file"]);
    }
    exit;
}

// Traditional file upload via $_FILES
if (!isset($_FILES['file'])) {
    echo json_encode(["success" => false, "message" => "No file uploaded"]);
    exit;
}

$file = $_FILES['file'];
$allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'application/pdf'];

// Validate file upload
if ($file['error'] !== UPLOAD_ERR_OK) {
    $upload_errors = [
        UPLOAD_ERR_INI_SIZE => "File exceeds server limit",
        UPLOAD_ERR_FORM_SIZE => "File exceeds form limit",
        UPLOAD_ERR_PARTIAL => "File only partially uploaded",
        UPLOAD_ERR_NO_FILE => "No file uploaded",
        UPLOAD_ERR_NO_TMP_DIR => "Missing temp folder",
        UPLOAD_ERR_CANT_WRITE => "Failed to write to disk",
        UPLOAD_ERR_EXTENSION => "Upload blocked by extension"
    ];
    $error_msg = isset($upload_errors[$file['error']]) ? $upload_errors[$file['error']] : "Unknown error";
    echo json_encode(["success" => false, "message" => $error_msg]);
    exit;
}

if (!in_array($file['type'], $allowed_types)) {
    echo json_encode(["success" => false, "message" => "Invalid file type. Allowed: JPG, PNG, GIF, PDF"]);
    exit;
}

if ($file['size'] > $max_size) {
    echo json_encode(["success" => false, "message" => "File too large. Max 5MB allowed"]);
    exit;
}

// Generate unique filename
$extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
$filename = $user_type . "_" . $user_id . "_" . $document_type . "_" . time() . "." . $extension;
$filepath = $upload_dir . $filename;

// Move uploaded file
if (move_uploaded_file($file['tmp_name'], $filepath)) {
    // Generate URL
    $protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https://' : 'http://';
    $host = $_SERVER['HTTP_HOST'];
    $file_url = $protocol . $host . "/jobbridge/" . $upload_dir . $filename;
    
    // Update database
    include 'db.php';
    
    if ($document_type === 'profile_photo' || $document_type === 'company_logo') {
        if ($user_type === 'worker') {
            $sql = "UPDATE workers SET profile_photo = ? WHERE id = ?";
        } else {
            $sql = "UPDATE employers SET profile_photo = ? WHERE id = ?";
        }
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $file_url, $user_id);
        $stmt->execute();
        $stmt->close();
    }
    
    $conn->close();
    
    echo json_encode([
        "success" => true,
        "message" => "File uploaded successfully",
        "file_url" => $file_url,
        "filename" => $filename
    ]);
} else {
    echo json_encode(["success" => false, "message" => "Failed to save file"]);
}
?>
