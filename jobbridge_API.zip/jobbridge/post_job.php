<?php
error_reporting(0);
header('Content-Type: application/json');
include "db.php";

// Get POST data
$data = json_decode(file_get_contents("php://input"), true);

// If JSON decode fails, try POST
if (!$data) {
    $data = $_POST;
}

// Required fields
$title = isset($data['title']) ? trim($data['title']) : '';
$description = isset($data['description']) ? trim($data['description']) : '';
$price = isset($data['price_per_hour']) ? intval($data['price_per_hour']) : 0;
$employer_id = isset($data['employer_id']) ? intval($data['employer_id']) : null;
$employer_name = isset($data['employer_name']) ? trim($data['employer_name']) : '';
$location = isset($data['location_text']) ? trim($data['location_text']) : '';
$category = isset($data['category']) ? trim($data['category']) : '';

// New fields
$job_type = isset($data['job_type']) ? $data['job_type'] : 'daily';
$shift_start = isset($data['shift_start']) ? $data['shift_start'] : null;
$shift_end = isset($data['shift_end']) ? $data['shift_end'] : null;
$urgency = isset($data['urgency']) ? $data['urgency'] : 'flexible';
$min_experience = isset($data['min_experience']) ? intval($data['min_experience']) : 0;
$required_skills = isset($data['required_skills']) ? trim($data['required_skills']) : null;
$benefits = isset($data['benefits']) ? trim($data['benefits']) : null;
$openings = isset($data['openings']) ? intval($data['openings']) : 1;
$duration_hours = isset($data['duration_hours']) ? intval($data['duration_hours']) : null;
$latitude = isset($data['latitude']) ? floatval($data['latitude']) : null;
$longitude = isset($data['longitude']) ? floatval($data['longitude']) : null;

// Validation
if (empty($title)) {
    echo json_encode(["success" => false, "message" => "Job title is required"]);
    exit;
}

if (empty($description)) {
    echo json_encode(["success" => false, "message" => "Job description is required"]);
    exit;
}

if ($price <= 0) {
    echo json_encode(["success" => false, "message" => "Valid price per hour is required"]);
    exit;
}

// Get employer details if employer_id provided
if ($employer_id) {
    $sql = "SELECT company_name FROM employers WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $employer_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $employer_name = $row['company_name'];
    }
    $stmt->close();
}

// Insert job
$sql = "INSERT INTO jobs (
            title, description, price_per_hour, employer_id, employer_name, 
            location_text, latitude, longitude, category, job_type, 
            shift_start, shift_end, urgency, min_experience, 
            required_skills, benefits, openings, duration_hours, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')";

$stmt = $conn->prepare($sql);
$stmt->bind_param(
    "ssiissddsssssisiii",
    $title, $description, $price, $employer_id, $employer_name,
    $location, $latitude, $longitude, $category, $job_type,
    $shift_start, $shift_end, $urgency, $min_experience,
    $required_skills, $benefits, $openings, $duration_hours
);

if ($stmt->execute()) {
    $job_id = $conn->insert_id;
    echo json_encode([
        "success" => true, 
        "message" => "Job posted successfully",
        "job_id" => $job_id
    ]);
} else {
    echo json_encode(["success" => false, "message" => "Failed to post job: " . $conn->error]);
}

$stmt->close();
$conn->close();
?>
