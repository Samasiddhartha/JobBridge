<?php
error_reporting(0);
header('Content-Type: application/json');
require_once "db.php";

$response = ["success" => false];

if (!isset($_GET['id'])) {
    echo json_encode(["success" => false, "message" => "Job ID missing"]);
    exit;
}

$job_id = intval($_GET['id']);
$worker_id = isset($_GET['worker_id']) ? intval($_GET['worker_id']) : 0;

$sql = "SELECT 
            id,
            title,
            description,
            price_per_hour,
            job_type,
            employer_id,
            employer_name,
            employer_rating,
            reviews_count,
            latitude,
            longitude,
            location_text,
            posted_at
        FROM jobs
        WHERE id = ? AND status = 'active'";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $job_id);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {

    $posted = "just now";
    if ($row['posted_at']) {
        $posted = timeAgo($row['posted_at']);
    }

    $response["success"] = true;
    $response["job"] = [
        "id" => $row["id"],
        "title" => $row["title"],
        "description" => $row["description"],
        "pay" => $row["price_per_hour"],
        "category" => $row["job_type"] ?? "General",
        "employer_id" => (int)$row["employer_id"],
        "employer" => $row["employer_name"],
        "rating" => $row["employer_rating"],
        "reviews" => $row["reviews_count"],
        "lat" => $row["latitude"],
        "lng" => $row["longitude"],
        "location" => $row["location_text"],
        "posted" => $posted
    ];
    
    // Check if worker has already applied
    if ($worker_id > 0) {
        $appSql = "SELECT id, status FROM applications WHERE job_id = ? AND user_id = ?";
        $appStmt = $conn->prepare($appSql);
        $appStmt->bind_param("ii", $job_id, $worker_id);
        $appStmt->execute();
        $appResult = $appStmt->get_result();
        
        if ($appRow = $appResult->fetch_assoc()) {
            $response["already_applied"] = true;
            $response["application_id"] = (int)$appRow["id"];
            $response["application_status"] = $appRow["status"];
        } else {
            $response["already_applied"] = false;
            $response["application_status"] = null;
        }
        $appStmt->close();
    }
}

$stmt->close();
$conn->close();
echo json_encode($response);


// helper function
function timeAgo($datetime) {
    $time = strtotime($datetime);
    $diff = time() - $time;

    if ($diff < 60) return "just now";
    if ($diff < 3600) return floor($diff/60) . " min ago";
    if ($diff < 86400) return floor($diff/3600) . " hrs ago";
    return floor($diff/86400) . " days ago";
}
?>
