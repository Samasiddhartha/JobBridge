<?php
error_reporting(0);
header('Content-Type: application/json');
include "db.php";

$worker_id = isset($_GET['worker_id']) ? intval($_GET['worker_id']) : 0;

if ($worker_id <= 0) {
    echo json_encode(["success" => false, "message" => "Invalid worker ID"]);
    exit;
}

// Get worker info
$stmt = $conn->prepare("SELECT id, name, mobile, email, profile_photo, is_verified, created_at FROM workers WHERE id = ?");
$stmt->bind_param("i", $worker_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo json_encode(["success" => false, "message" => "Worker not found"]);
    $stmt->close();
    exit;
}

$worker = $result->fetch_assoc();
$stmt->close();

// Get worker profile details
$profileStmt = $conn->prepare("SELECT skills, experience, hourly_rate FROM worker_profiles WHERE worker_id = ?");
$profileStmt->bind_param("i", $worker_id);
$profileStmt->execute();
$profileResult = $profileStmt->get_result();
$profile = $profileResult->fetch_assoc();
$profileStmt->close();

// Get rating stats
$ratingStmt = $conn->prepare("SELECT AVG(rating) as avg_rating, COUNT(*) as total_reviews FROM worker_ratings WHERE worker_id = ?");
$ratingStmt->bind_param("i", $worker_id);
$ratingStmt->execute();
$ratingResult = $ratingStmt->get_result();
$ratings = $ratingResult->fetch_assoc();
$ratingStmt->close();

// Get job stats
$jobsStmt = $conn->prepare("SELECT COUNT(*) as jobs_completed, SUM(total_earned) as total_earned FROM work_history WHERE worker_id = ? AND status = 'completed'");
$jobsStmt->bind_param("i", $worker_id);
$jobsStmt->execute();
$jobsResult = $jobsStmt->get_result();
$jobStats = $jobsResult->fetch_assoc();
$jobsStmt->close();

echo json_encode([
    "success" => true,
    "worker" => [
        "id" => (int)$worker['id'],
        "name" => $worker['name'],
        "mobile" => $worker['mobile'],
        "email" => $worker['email'],
        "profile_photo" => $worker['profile_photo'],
        "is_verified" => (int)$worker['is_verified'],
        "member_since" => $worker['created_at']
    ],
    "profile" => [
        "skills" => $profile['skills'] ?? "",
        "experience" => (int)($profile['experience'] ?? 0),
        "hourly_rate" => (int)($profile['hourly_rate'] ?? 0)
    ],
    "stats" => [
        "avg_rating" => round((float)($ratings['avg_rating'] ?? 0), 1),
        "total_reviews" => (int)($ratings['total_reviews'] ?? 0),
        "jobs_completed" => (int)($jobStats['jobs_completed'] ?? 0),
        "total_earned" => (float)($jobStats['total_earned'] ?? 0)
    ]
]);

$conn->close();
?>
