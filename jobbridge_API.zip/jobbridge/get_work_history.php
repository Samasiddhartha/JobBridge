<?php
error_reporting(0);
header('Content-Type: application/json');
include "db.php";

$worker_id = isset($_GET['worker_id']) ? intval($_GET['worker_id']) : 0;

if ($worker_id <= 0) {
    echo json_encode(["success" => false, "message" => "Invalid worker ID"]);
    exit;
}

$stmt = $conn->prepare("
    SELECT id, job_id, job_title, employer_name, start_date, end_date, 
           hours_worked, total_earned, status, created_at 
    FROM work_history 
    WHERE worker_id = ?
    ORDER BY end_date DESC
");
$stmt->bind_param("i", $worker_id);
$stmt->execute();
$result = $stmt->get_result();

$history = [];
$total_jobs = 0;
$total_hours = 0;
$total_earnings = 0;

while ($row = $result->fetch_assoc()) {
    $history[] = [
        "id" => (int)$row['id'],
        "job_id" => (int)$row['job_id'],
        "job_title" => $row['job_title'],
        "employer_name" => $row['employer_name'],
        "start_date" => $row['start_date'],
        "end_date" => $row['end_date'],
        "hours_worked" => (float)$row['hours_worked'],
        "total_earned" => (float)$row['total_earned'],
        "status" => $row['status']
    ];
    
    if ($row['status'] == 'completed') {
        $total_jobs++;
        $total_hours += (float)$row['hours_worked'];
        $total_earnings += (float)$row['total_earned'];
    }
}

echo json_encode([
    "success" => true,
    "summary" => [
        "total_jobs" => $total_jobs,
        "total_hours" => round($total_hours, 1),
        "total_earnings" => $total_earnings
    ],
    "history" => $history
]);

$stmt->close();
$conn->close();
?>
